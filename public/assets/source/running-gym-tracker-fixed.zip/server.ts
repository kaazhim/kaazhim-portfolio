import express from "express";
import path from "path";
import cors from "cors";
import cookieParser from "cookie-parser";
import { createServer as createViteServer } from "vite";
import SpotifyWebApi from "spotify-web-api-node";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cors());
  app.use(cookieParser());

  // Initialize Gemini AI
  let ai: GoogleGenAI | null = null;
  if (process.env.GEMINI_API_KEY) {
    ai = new GoogleGenAI({ 
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }

  const getRedirectUri = () => {
    // We use the exact dynamic app URL inside AI Studio
    return `${process.env.APP_URL || ('http://localhost:' + PORT)}/auth/spotify/callback`;
  };

  const getSpotifyApi = (req: any) => {
    return new SpotifyWebApi({
      clientId: process.env.SPOTIFY_CLIENT_ID,
      clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
      redirectUri: getRedirectUri(),
    });
  };

  // --- API Routes ---
  
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Spotify Auth URL Endpoint
  app.get("/api/auth/spotify/url", (req, res) => {
    try {
      if (!process.env.SPOTIFY_CLIENT_ID || !process.env.SPOTIFY_CLIENT_SECRET) {
        return res.status(400).json({ error: "Spotify credentials are not configured in settings." });
      }
      
      const spotifyApi = getSpotifyApi(req);
      const scopes = [
        'user-read-private', 
        'user-read-email', 
        'playlist-read-private', 
        'user-top-read',
        'user-read-recently-played',
        'user-read-playback-state',
        'user-modify-playback-state',
        'user-read-currently-playing'
      ];
      const state = 'aura-active-auth-state';
      const authorizeURL = spotifyApi.createAuthorizeURL(scopes, state);
      
      res.json({ url: authorizeURL });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Spotify Callback HTML (Pop-up flow)
  app.get(["/auth/spotify/callback", "/auth/spotify/callback/"], async (req, res) => {
    const error = req.query.error;
    const code = req.query.code as string;

    if (error) {
      return res.send(`<html><body>Error: ${error}</body></html>`);
    }

    try {
      const spotifyApi = getSpotifyApi(req);
      const data = await spotifyApi.authorizationCodeGrant(code);
      const access_token = data.body['access_token'];
      const refresh_token = data.body['refresh_token'];
      const expires_in = data.body['expires_in'];

      // Send success message to parent window and close popup
      // Pass the tokens back via postMessage so the client can save them
      res.send(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({ 
                  type: 'OAUTH_AUTH_SUCCESS',
                  payload: {
                    access_token: '${access_token}',
                    refresh_token: '${refresh_token}',
                    expires_in: ${expires_in}
                  }
                }, '*');
                window.close();
              } else {
                window.location.href = '/';
              }
            </script>
            <p>Authentication successful. This window should close automatically.</p>
          </body>
        </html>
      `);
    } catch (e: any) {
      res.send(`<html><body>Error during callback: ${e.message}</body></html>`);
    }
  });

  // Spotify Proxy - Get Current User
  app.post("/api/spotify/me", async (req, res) => {
    const { accessToken } = req.body;
    if (!accessToken) return res.status(401).json({ error: "Missing token" });

    try {
      const spotifyApi = new SpotifyWebApi();
      spotifyApi.setAccessToken(accessToken);
      const me = await spotifyApi.getMe();
      res.json(me.body);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Spotify Proxy - Get Recently Played
  app.post("/api/spotify/recent", async (req, res) => {
    const { accessToken } = req.body;
    if (!accessToken) return res.status(401).json({ error: "Missing token" });

    try {
      const spotifyApi = new SpotifyWebApi();
      spotifyApi.setAccessToken(accessToken);
      const recent = await spotifyApi.getMyRecentlyPlayedTracks({ limit: 5 });
      res.json(recent.body.items);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Spotify Proxy - Now Playing
  app.post("/api/spotify/now-playing", async (req, res) => {
    const { accessToken } = req.body;
    if (!accessToken) return res.status(401).json({ error: "Missing token" });

    try {
      const spotifyApi = new SpotifyWebApi();
      spotifyApi.setAccessToken(accessToken);
      const data = await spotifyApi.getMyCurrentPlaybackState();
      
      if (data.statusCode === 204 || data.statusCode === 202) {
        return res.json({ isPlaying: false });
      }
      return res.json(data.body);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Spotify Proxy - Controls
  app.post("/api/spotify/control", async (req, res) => {
    const { accessToken, action } = req.body;
    if (!accessToken) return res.status(401).json({ error: "Missing token" });

    try {
      const spotifyApi = new SpotifyWebApi();
      spotifyApi.setAccessToken(accessToken);
      
      if (action === "play") await spotifyApi.play();
      else if (action === "pause") await spotifyApi.pause();
      else if (action === "next") await spotifyApi.skipToNext();
      else if (action === "previous") await spotifyApi.skipToPrevious();
      
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Gemini Pro AI Route: Analyze and Suggest
  app.post("/api/gemini/analyze-vibe", async (req, res) => {
    try {
      if (!ai) {
        return res.status(500).json({ error: "Gemini AI is not configured." });
      }

      const { workouts, meals, recentArtists } = req.body;

      const prompt = `
      I am building a smart health app called Aura Active. I need you to analyze my recent activity and give me a custom music/vibe suggestion!
      
      Recent Workouts: ${JSON.stringify(workouts)}
      Recent Meals: ${JSON.stringify(meals)}
      Recently Listened To: ${JSON.stringify(recentArtists)}
      
      Give me a 3-sentence encouraging summary of how I'm doing and suggest a genre or vibe of music (like "High-BPM Techno" or "Lofi Chillhop") to listen to based on my intensity.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: prompt
      });

      res.json({ text: response.text });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
