/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WorkoutType = 'gym' | 'running';

export interface BaseWorkout {
  id: string;
  date: string;
  type: WorkoutType;
  durationMinutes: number;
  caloriesBurned: number;
  notes?: string;
  isCompleted: boolean;
}

export interface GymExercise {
  id: string;
  name: string;
  category: 'strength' | 'cardio' | 'hypertrophy' | 'flexibility' | 'core';
  targetMuscle: string;
  sets: {
    id: string;
    reps: number;
    weightKg: number;
    isCompleted: boolean;
  }[];
}

export interface GymWorkout extends BaseWorkout {
  type: 'gym';
  gymType: 'push' | 'pull' | 'legs' | 'upper' | 'lower' | 'fullbody' | 'custom';
  exercises: GymExercise[];
}

export interface RunningWorkout extends BaseWorkout {
  type: 'running';
  distanceKm: number;
  pacePerKm: string; // MM:SS format
  routeType: 'treadmill' | 'road' | 'trail' | 'track';
  elevationGainM?: number;
  averageHeartRate?: number;
}

export type Workout = GymWorkout | RunningWorkout;

export interface FoodItem {
  id: string;
  name: string;
  calories: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
  servingSize: string;
}

export type MealTime = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface Meal {
  id: string;
  mealTime: MealTime;
  name: string;
  items: FoodItem[];
  isCompleted: boolean;
  notes?: string;
}

export interface DailyMetrics {
  date: string;
  waterIntakeMl: number;
  waterGoalMl: number;
  weightKg?: number;
  sleepHours?: number;
  activeMinutes: number;
}

export interface UserGoals {
  dailyWaterMl: number;
  dailyCaloriesBurned: number;
  dailyCalorieIntake: number;
  weeklyRunningDistanceKm: number;
  weeklyGymWorkouts: number;
}

export interface DashboardStats {
  weeklyWorkoutsCount: number;
  weeklyRunningKm: number;
  todayWaterMl: number;
  todayCaloriesIntake: number;
  todayCaloriesBurned: number;
}
