/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Plus, 
  Trash2, 
  TrendingUp, 
  Compass, 
  Calendar, 
  Clock, 
  Flame, 
  Check, 
  Grid, 
  History,
  Zap,
  Tag,
  Dumbbell
} from 'lucide-react';
import { Workout, GymWorkout, RunningWorkout, GymExercise } from '../types';

interface WorkoutTrackerProps {
  workouts: Workout[];
  onAddWorkout: (workout: Workout) => void;
  onDeleteWorkout: (id: string) => void;
}

export default function WorkoutTracker({
  workouts,
  onAddWorkout,
  onDeleteWorkout,
}: WorkoutTrackerProps) {
  const [activeTab, setActiveTab] = useState<'log' | 'history'>('log');
  const [workoutType, setWorkoutType] = useState<'gym' | 'running'>('gym');
  const [filterType, setFilterType] = useState<'all' | 'gym' | 'running'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Gym Workout Form State
  const [gymTitle, setGymTitle] = useState('Upper Body Push Routine');
  const [gymNotes, setGymNotes] = useState('');
  const [gymDuration, setGymDuration] = useState('60');
  const [gymCalories, setGymCalories] = useState('350');
  const [exercises, setExercises] = useState<GymExercise[]>([
    {
      id: 'e-1',
      name: 'Incline Bench Press',
      category: 'strength',
      targetMuscle: 'Chest',
      sets: [
        { id: 's-1-1', reps: 10, weightKg: 20, isCompleted: false },
        { id: 's-1-2', reps: 10, weightKg: 20, isCompleted: false },
      ]
    },
    {
      id: 'e-2',
      name: 'Overhead Lateral Raise',
      category: 'hypertrophy',
      targetMuscle: 'Shoulders',
      sets: [
        { id: 's-2-1', reps: 12, weightKg: 8, isCompleted: false }
      ]
    }
  ]);

  // Running Workout Form State
  const [runNotes, setRunNotes] = useState('');
  const [runDuration, setRunDuration] = useState('30');
  const [runCalories, setRunCalories] = useState('280');
  const [runDistance, setRunDistance] = useState('5.0');
  const [runPace, setRunPace] = useState('06:00');
  const [runRoute, setRunRoute] = useState<'road' | 'treadmill' | 'trail' | 'track'>('road');
  const [runElevation, setRunElevation] = useState('20');
  const [runHR, setRunHR] = useState('145');

  // Interactive Stopwatch / Rest Timer State (Not Ordinary!)
  const [timerSeconds, setTimerSeconds] = useState(60);
  const [initialTimerSetting, setInitialTimerSetting] = useState(60);
  const [timerActive, setTimerActive] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (timerActive && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(s => s - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setTimerActive(false);
      // Optional subtle sound or notification could go here
    }
    return () => clearInterval(interval);
  }, [timerActive, timerSeconds]);

  const handleStartTimer = (seconds: number) => {
    setTimerSeconds(seconds);
    setInitialTimerSetting(seconds);
    setTimerActive(true);
  };

  // Gym Workout logic helpers
  const handleAddNewExercise = () => {
    const categories: ('strength' | 'hypertrophy' | 'flexibility' | 'core')[] = ['strength', 'hypertrophy', 'core'];
    const newEx: GymExercise = {
      id: `ex-${Date.now()}`,
      name: 'New Exercise',
      category: 'strength',
      targetMuscle: 'Full Body',
      sets: [{ id: `set-${Date.now()}-1`, reps: 10, weightKg: 10, isCompleted: false }]
    };
    setExercises([...exercises, newEx]);
  };

  const handleUpdateExerciseText = (id: string, name: string, targetMuscle: string) => {
    setExercises(exercises.map(ex => {
      if (ex.id === id) {
        return { ...ex, name, targetMuscle };
      }
      return ex;
    }));
  };

  const handleUpdateExerciseSet = (exerciseId: string, setId: string, reps: number, weightKg: number) => {
    setExercises(exercises.map(ex => {
      if (ex.id === exerciseId) {
        return {
          ...ex,
          sets: ex.sets.map(s => s.id === setId ? { ...s, reps, weightKg } : s)
        };
      }
      return ex;
    }));
  };

  const handleToggleSetCompleted = (exerciseId: string, setId: string) => {
    setExercises(exercises.map(ex => {
      if (ex.id === exerciseId) {
        return {
          ...ex,
          sets: ex.sets.map(s => s.id === setId ? { ...s, isCompleted: !s.isCompleted } : s)
        };
      }
      return ex;
    }));
  };

  const handleAddSetToExercise = (exerciseId: string) => {
    setExercises(exercises.map(ex => {
      if (ex.id === exerciseId) {
        const lastSet = ex.sets[ex.sets.length - 1] || { reps: 10, weightKg: 10 };
        return {
          ...ex,
          sets: [...ex.sets, {
            id: `set-${Date.now()}-${ex.sets.length + 1}`,
            reps: lastSet.reps,
            weightKg: lastSet.weightKg,
            isCompleted: false
          }]
        };
      }
      return ex;
    }));
  };

  const handleDeleteSetFromExercise = (exerciseId: string, setId: string) => {
    setExercises(exercises.map(ex => {
      if (ex.id === exerciseId) {
        return {
          ...ex,
          sets: ex.sets.filter(s => s.id !== setId)
        };
      }
      return ex;
    }));
  };

  const handleDeleteExercise = (id: string) => {
    setExercises(exercises.filter(ex => ex.id !== id));
  };

  // Submit Gym Workout
  const handleSubmitGym = (e: React.FormEvent) => {
    e.preventDefault();
    if (exercises.length === 0) return;

    // Filter out exercises with no sets
    const validExercises = exercises.filter(ex => ex.sets.length > 0);

    const newGymWorkout: GymWorkout = {
      id: `w-gym-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      type: 'gym',
      durationMinutes: parseFloat(gymDuration) || 45,
      caloriesBurned: parseFloat(gymCalories) || 300,
      notes: gymNotes || 'Elegantly tracked strength workout',
      isCompleted: true,
      gymType: 'custom',
      exercises: validExercises
    };

    onAddWorkout(newGymWorkout);
    setActiveTab('history');
    
    // Reset inputs
    setGymNotes('');
    setExercises([
      {
        id: 'e-1',
        name: 'Incline Bench Press',
        category: 'strength',
        targetMuscle: 'Chest',
        sets: [{ id: 's-1-1', reps: 10, weightKg: 20, isCompleted: false }]
      }
    ]);
  };

  // Submit Running Workout
  const handleSubmitRunning = (e: React.FormEvent) => {
    e.preventDefault();

    const newRunWorkout: RunningWorkout = {
      id: `w-run-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      type: 'running',
      durationMinutes: parseFloat(runDuration) || 30,
      caloriesBurned: parseFloat(runCalories) || 280,
      notes: runNotes || 'Aesthetic outdoor path run',
      isCompleted: true,
      distanceKm: parseFloat(runDistance) || 5.0,
      pacePerKm: runPace || '06:00',
      routeType: runRoute,
      elevationGainM: parseFloat(runElevation) || 0,
      averageHeartRate: parseFloat(runHR) || 140,
    };

    onAddWorkout(newRunWorkout);
    setActiveTab('history');

    // Reset inputs
    setRunNotes('');
    setRunDistance('5.0');
    setRunPace('06:00');
  };

  // Filter and search logic for history tab
  const filteredWorkouts = workouts.filter(w => {
    const matchesType = filterType === 'all' || w.type === filterType;
    const notesLower = (w.notes || '').toLowerCase();
    const matchesSearch = searchQuery === '' || 
      notesLower.includes(searchQuery.toLowerCase()) ||
      (w.type === 'gym' && w.exercises.some(e => e.name.toLowerCase().includes(searchQuery.toLowerCase())));
    return matchesType && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Tab Navigation header */}
      <div className="flex border-b border-stone-100 pb-1 justify-between items-center bg-stone-50/50 p-1.5 rounded-full border">
        <div className="flex gap-1 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('log')}
            className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-2 rounded-full text-xs font-semibold tracking-tight transition-all cursor-pointer ${
              activeTab === 'log'
                ? 'bg-white text-stone-800 shadow-sm'
                : 'text-stone-400 hover:text-stone-700'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            Log New Experience
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-2 rounded-full text-xs font-semibold tracking-tight transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'bg-white text-stone-800 shadow-sm'
                : 'text-stone-400 hover:text-stone-700'
            }`}
            id="workout-history-tab"
          >
            <History className="w-3.5 h-3.5" />
            Past Exercises ({workouts.length})
          </button>
        </div>

        {/* Dynamic circular rest timer inside selection headers */}
        <div className="hidden md:flex items-center gap-3 bg-stone-100/50 px-4 py-1.5 rounded-full border border-stone-200/50">
          <Clock className="w-3.5 h-3.5 text-stone-500" />
          <span className="text-xs font-mono font-medium text-stone-600">
            Rest Check: {Math.floor(timerSeconds / 60)}:{(timerSeconds % 60).toString().padStart(2, '0')}
          </span>
          <div className="flex gap-1">
            <button 
              onClick={() => handleStartTimer(60)}
              className="text-[10px] bg-white border border-stone-200 px-1.5 py-0.5 rounded hover:bg-stone-50 text-stone-600 cursor-pointer"
            >
              60s
            </button>
            <button 
              onClick={() => handleStartTimer(90)}
              className="text-[10px] bg-white border border-stone-200 px-1.5 py-0.5 rounded hover:bg-stone-50 text-stone-600 cursor-pointer"
            >
              90s
            </button>
            <button 
              onClick={() => setTimerActive(!timerActive)}
              className="p-1 text-stone-600 hover:text-stone-800 transition"
              title="Pause/Resume"
            >
              {timerActive ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'log' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Form Side - Gym routing vs Run Trail tracker */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Type selector toggle */}
            <div className="flex bg-stone-100 rounded-2xl p-1.5 max-w-[280px]">
              <button 
                onClick={() => setWorkoutType('gym')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  workoutType === 'gym' ? 'bg-white text-stone-800 shadow-sm' : 'text-stone-400'
                }`}
              >
                <Dumbbell className="w-3.5 h-3.5" />
                Gym / Strength
              </button>
              <button 
                onClick={() => setWorkoutType('running')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  workoutType === 'running' ? 'bg-white text-stone-800 shadow-sm' : 'text-stone-400'
                }`}
                id="select-running-activity"
              >
                <Compass className="w-3.5 h-3.5" />
                Trail / Running
              </button>
            </div>

            {workoutType === 'gym' ? (
              /* GYM WORKOUT LOGGING INTERFACE */
              <form onSubmit={handleSubmitGym} className="bg-white border border-stone-100 p-6 rounded-3xl shadow-sm space-y-6" id="gym-log-form">
                <div className="border-b border-stone-100 pb-4">
                  <h3 className="text-lg font-light text-stone-800 tracking-tight">Schedule Gym Session</h3>
                  <p className="text-xs text-stone-400 mt-1">Design exercises and record weight achievements</p>
                </div>

                {/* Duration & Calories row */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1">Time Elapsed (minutes)</label>
                    <input 
                      type="number" 
                      value={gymDuration}
                      onChange={e => setGymDuration(e.target.value)}
                      className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1">Energy Melted (kcal)</label>
                    <input 
                      type="number" 
                      value={gymCalories}
                      onChange={e => setGymCalories(e.target.value)}
                      className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none"
                      required
                    />
                  </div>
                </div>

                {/* Exercises Stack */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <span className="text-xs uppercase tracking-wider font-mono text-stone-400">Recorded Exercises</span>
                    <button 
                      type="button"
                      onClick={handleAddNewExercise}
                      className="flex items-center gap-1.5 text-xs text-stone-700 bg-stone-50 hover:bg-stone-100 px-3 py-1.5 rounded-full border border-stone-200 transition-colors"
                      id="add-exercise-btn"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add Exercise Block
                    </button>
                  </div>

                  <div className="space-y-4">
                    {exercises.map((ex, exIdx) => (
                      <div key={ex.id} className="p-4 bg-[#fafaf9] rounded-2xl border border-stone-250/30 space-y-3 relative group">
                        
                        {/* Title Delete cross */}
                        <button 
                          type="button"
                          onClick={() => handleDeleteExercise(ex.id)}
                          className="absolute top-4 right-4 text-stone-300 hover:text-stone-600 transition"
                          title="Remove Exercise"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mr-6">
                          <div>
                            <label className="block text-[10px] font-medium text-stone-400 uppercase tracking-wider mb-0.5">Exercise Name</label>
                            <input 
                              type="text"
                              value={ex.name}
                              onChange={e => handleUpdateExerciseText(ex.id, e.target.value, ex.targetMuscle)}
                              className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-medium focus:outline-none"
                              placeholder="Bench Press, Squats, etc"
                              required
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-medium text-stone-400 uppercase tracking-wider mb-0.5">Target Muscle / Zone</label>
                            <input 
                              type="text"
                              value={ex.targetMuscle}
                              onChange={e => handleUpdateExerciseText(ex.id, ex.name, e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs focus:outline-none"
                              placeholder="Chest, Quads, Delts..."
                            />
                          </div>
                        </div>

                        {/* Sets sub-table */}
                        <div className="pt-2">
                          <span className="text-[10px] font-mono uppercase text-stone-400 block mb-1.5">Weight & Reps Table</span>
                          <div className="space-y-2">
                            {ex.sets.map((set, setIdx) => (
                              <div key={set.id} className="flex items-center gap-3 bg-white p-2 border border-stone-200/50 rounded-xl">
                                <span className="text-[10px] font-mono text-stone-400 w-10">Set {setIdx + 1}</span>
                                
                                <div className="flex items-center gap-1.5 flex-1 max-w-[140px]">
                                  <input 
                                    type="number"
                                    value={set.weightKg}
                                    onChange={e => handleUpdateExerciseSet(ex.id, set.id, set.reps, parseFloat(e.target.value) || 0)}
                                    className="w-full p-1 border border-stone-200 rounded text-center text-xs font-mono"
                                    placeholder="Weight"
                                    min="0"
                                    required
                                  />
                                  <span className="text-[10px] text-stone-400 font-mono">kg</span>
                                </div>

                                <div className="flex items-center gap-1.5 flex-1 max-w-[140px]">
                                  <input 
                                    type="number"
                                    value={set.reps}
                                    onChange={e => handleUpdateExerciseSet(ex.id, set.id, parseInt(e.target.value) || 0, set.weightKg)}
                                    className="w-full p-1 border border-stone-200 rounded text-center text-xs font-mono"
                                    placeholder="Reps"
                                    min="0"
                                    required
                                  />
                                  <span className="text-[10px] text-stone-45px font-mono">reps</span>
                                </div>

                                {/* Checklist circle */}
                                <button
                                  type="button"
                                  onClick={() => handleToggleSetCompleted(ex.id, set.id)}
                                  className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${
                                    set.isCompleted 
                                      ? 'bg-emerald-100 text-emerald-600 border border-emerald-300' 
                                      : 'border border-stone-300 hover:border-emerald-400'
                                  }`}
                                >
                                  {set.isCompleted && <Check className="w-3 h-3" />}
                                </button>

                                <button 
                                  type="button"
                                  onClick={() => handleDeleteSetFromExercise(ex.id, set.id)}
                                  className="text-stone-300 hover:text-rose-500 p-0.5 rounded transition"
                                  title="Delete set"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>

                          <button 
                            type="button"
                            onClick={() => handleAddSetToExercise(ex.id)}
                            className="mt-2 text-[11px] font-mono text-stone-500 hover:text-stone-800 flex items-center gap-1"
                          >
                            <Plus className="w-3 h-3" /> Add Set Record
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                </div>

                {/* Routine Notes */}
                <div>
                  <label className="block text-xs font-medium text-stone-500 mb-1">Session Experience & Notes</label>
                  <textarea 
                    value={gymNotes}
                    onChange={e => setGymNotes(e.target.value)}
                    className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-2xl text-xs focus:outline-none min-h-[70px]"
                    placeholder="Focus level, muscle contractility comments, hydration highlights..."
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white rounded-2xl text-xs font-medium tracking-tight transition-all cursor-pointer shadow-sm"
                  id="submit-gym-workout"
                >
                  Confirm Workout Details
                </button>
              </form>
            ) : (
              /* RUNNING LOGGING INTERFACE */
              <form onSubmit={handleSubmitRunning} className="bg-white border border-stone-100 p-6 rounded-3xl shadow-sm space-y-6" id="run-log-form">
                <div className="border-b border-stone-100 pb-4">
                  <h3 className="text-lg font-light text-stone-800 tracking-tight">Record Running Performance</h3>
                  <p className="text-xs text-stone-400 mt-1">Monitor distance, route pace, heart rate, and trails</p>
                </div>

                {/* Coordinates top row */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1">Target Distance (km)</label>
                    <input 
                      type="number" 
                      step="0.01"
                      value={runDistance}
                      onChange={e => setRunDistance(e.target.value)}
                      className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1">Average Pace (min/km, MM:SS)</label>
                    <input 
                      type="text" 
                      value={runPace}
                      placeholder="e.g. 05:45"
                      onChange={e => setRunPace(e.target.value)}
                      className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none font-mono"
                      required
                    />
                  </div>
                </div>

                {/* Speed Time Calculations */}
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1">Minutes Duration</label>
                    <input 
                      type="number" 
                      value={runDuration}
                      onChange={e => setRunDuration(e.target.value)}
                      className="w-full px-2 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1">Est Calories (kcal)</label>
                    <input 
                      type="number" 
                      value={runCalories}
                      onChange={e => setRunCalories(e.target.value)}
                      className="w-full px-2 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1">Route Element</label>
                    <select 
                      value={runRoute}
                      onChange={e => setRunRoute(e.target.value as any)}
                      className="w-full px-2 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-xs focus:outline-none"
                    >
                      <option value="road">Outdoor Road</option>
                      <option value="treadmill">Gym Treadmill</option>
                      <option value="trail">Rustic Trail</option>
                      <option value="track">Pro Track</option>
                    </select>
                  </div>
                </div>

                {/* Additional metrics */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1 flex items-center gap-1">
                      Elevation Gain (meters)
                    </label>
                    <input 
                      type="number" 
                      value={runElevation}
                      onChange={e => setRunElevation(e.target.value)}
                      className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-500 mb-1 flex items-center gap-1">
                      Avg Cardio Heart Rate (BPM)
                    </label>
                    <input 
                      type="number" 
                      value={runHR}
                      onChange={e => setRunHR(e.target.value)}
                      className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-xl text-sm focus:outline-none font-mono"
                    />
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-xs font-medium text-stone-500 mb-1">Trail Notes</label>
                  <textarea 
                    value={runNotes}
                    onChange={e => setRunNotes(e.target.value)}
                    className="w-full px-3 py-2 bg-[#fafaf9] border border-stone-200/80 rounded-2xl text-xs focus:outline-none min-h-[70px]"
                    placeholder="Temperature conditions, ankle cushioning feel, muscle oxygenation indicators..."
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white rounded-2xl text-xs font-medium tracking-tight transition-all cursor-pointer shadow-sm"
                  id="submit-run-workout"
                >
                  Log Running Session
                </button>
              </form>
            )}

          </div>

          {/* Right Column - Extra Tools: Circular Rest Timer & Fitness Calculations */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Dedicated Circular Rest Timer (Bespoke UI) */}
            <div className="bg-[#faf5ff] border border-purple-100 rounded-3xl p-6 shadow-sm text-center relative overflow-hidden" id="rest-timer-box">
              <div className="absolute top-0 right-0 w-24 h-24 bg-purple-100/30 rounded-full blur-2xl" />
              
              <h4 className="text-xs uppercase tracking-widest text-purple-600 font-mono mb-2">Aesthetic Rest Timer</h4>
              <p className="text-[11px] text-stone-400 mb-4 font-sans">Maximize muscle gains by optimizing set intervals</p>

              {/* Timer Progress display */}
              <div className="flex items-center justify-center my-6">
                <div className="w-32 h-32 rounded-full border-4 border-white/60 shadow-lg bg-white flex flex-col items-center justify-center relative">
                  {/* Subtle decorative spinning ring */}
                  <div className={`absolute inset-0 rounded-full border-2 border-dashed border-purple-300/40 animate-[spin_40s_linear_infinite] ${timerActive ? 'opacity-100' : 'opacity-0'}`} />
                  
                  <span className="text-3xl font-semibold font-mono tracking-tight text-purple-900 mt-2">
                    {Math.floor(timerSeconds / 60)}:{(timerSeconds % 60).toString().padStart(2, '0')}
                  </span>
                  <span className="text-[10px] font-mono text-purple-400 uppercase tracking-wider mt-0.5">
                    {timerActive ? 'resting now' : 'paused'}
                  </span>
                </div>
              </div>

              {/* Presets Grid */}
              <div className="grid grid-cols-4 gap-2 mb-4">
                {[30, 45, 60, 90].map(s => (
                  <button
                    key={s}
                    onClick={() => handleStartTimer(s)}
                    className="py-1.5 bg-white hover:bg-stone-50 border border-stone-200 rounded-lg text-xs font-mono font-medium text-stone-600 transition cursor-pointer"
                  >
                    {s}s
                  </button>
                ))}
              </div>

              {/* Controls */}
              <div className="flex justify-center gap-3">
                <button
                  onClick={() => setTimerActive(!timerActive)}
                  className={`px-4 py-2 rounded-xl text-xs font-medium cursor-pointer transition-colors flex items-center gap-1 ${
                    timerActive 
                      ? 'bg-purple-200 text-purple-800 font-semibold' 
                      : 'bg-stone-800 text-white hover:bg-stone-900'
                  }`}
                >
                  {timerActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  {timerActive ? 'Wait' : 'Begin'}
                </button>
                <button
                  onClick={() => { setTimerSeconds(60); setTimerActive(false); }}
                  className="p-2 border border-stone-300 rounded-xl hover:bg-stone-50 text-stone-500 cursor-pointer"
                  title="Reset Timer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Quick Gym Calculations panel */}
            <div className="bg-stone-50 border border-stone-200/60 rounded-3xl p-6 space-y-4">
              <h4 className="text-xs font-display font-medium uppercase tracking-wider text-stone-600">Dynamic Pace Guide</h4>
              <p className="text-xs text-stone-400">Determine your hourly performance speed from distance goals:</p>
              
              <div className="space-y-2 font-mono text-xs text-stone-600">
                <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                  <span>5K Race Pace Target:</span>
                  <span className="font-semibold text-emerald-600">05:00 /km</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                  <span>10K Steady Endurance:</span>
                  <span className="font-semibold text-sky-600">05:45 /km</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                  <span>Relaxed Recovery jog:</span>
                  <span className="font-semibold text-purple-600">06:30 /km</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      ) : (
        /* WORKOUT HISTORY INTERFACE WITH DYNAMIC SEARCH / FILTERS */
        <div className="space-y-6">
          
          {/* Filters Bar */}
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center bg-white border border-stone-100 p-4 rounded-2xl shadow-xs">
            <div className="flex items-center gap-2">
              <span className="text-xs text-stone-400 font-medium">Filter Type:</span>
              <div className="flex bg-stone-50 p-1 border border-stone-100 rounded-lg">
                {(['all', 'gym', 'running'] as const).map(t => (
                  <button
                    key={t}
                    onClick={() => setFilterType(t)}
                    className={`px-3 py-1 text-xs rounded transition uppercase font-mono tracking-tight cursor-pointer ${
                      filterType === t 
                        ? 'bg-stone-800 text-white font-medium' 
                        : 'text-stone-400 hover:text-stone-700'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Search Input */}
            <input 
              type="text"
              placeholder="Search exercise nodes or notes..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full sm:w-64 px-3 py-1.5 bg-stone-50 border border-stone-200/80 rounded-xl text-xs focus:outline-none"
            />
          </div>

          {/* Records Grid */}
          {filteredWorkouts.length === 0 ? (
            <div className="bg-white border border-dashed border-stone-200 text-center py-12 rounded-3xl">
              <Compass className="w-10 h-10 text-stone-300 mx-auto mb-3" />
              <p className="text-sm font-medium text-stone-500">No workout records coincide with filters</p>
              <p className="text-xs text-stone-400 mt-1">Initialize logs above to begin tracking stats</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredWorkouts.map(w => (
                <div 
                  key={w.id} 
                  className={`bg-white border p-5 rounded-3xl shadow-xs flex flex-col justify-between transition-all hover:shadow-sm ${
                    w.type === 'gym' ? 'border-purple-100' : 'border-sky-100'
                  }`}
                  id={`history-${w.id}`}
                >
                  <div>
                    {/* Header bar */}
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <span className={`text-[9px] uppercase tracking-wider font-mono font-bold px-2 py-0.5 rounded-full ${
                          w.type === 'gym' 
                            ? 'bg-[#faf5ff] text-purple-600' 
                            : 'bg-[#f0f9ff] text-sky-600'
                        }`}>
                          {w.type === 'gym' ? '💪 Gym Session' : '🏃 Trail Running'}
                        </span>
                        <h4 className="text-sm font-semibold text-stone-800 font-display mt-1.5">
                          {w.type === 'gym' ? 'Strength Workout Routing' : `Road run ${w.distanceKm} km`}
                        </h4>
                      </div>
                      
                      {/* Delete button */}
                      <button 
                        onClick={() => onDeleteWorkout(w.id)}
                        className="text-stone-300 hover:text-red-500 transition-colors p-1"
                        title="Delete log record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Metadata elements bar */}
                    <div className="grid grid-cols-3 gap-2 border-y border-stone-50 py-2.5 my-3 text-xs font-mono text-stone-500">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-stone-400" />
                        <span>{w.date}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-stone-400" />
                        <span>{w.durationMinutes}m</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Flame className="w-3.5 h-3.5 text-stone-400" />
                        <span className="text-stone-700 font-medium">{w.caloriesBurned} kcal</span>
                      </div>
                    </div>

                    {/* Specific details rendering */}
                    {w.type === 'gym' ? (
                      <div className="space-y-2 mt-4">
                        <span className="text-[10px] text-stone-400 font-mono block">Exercise details:</span>
                        <div className="space-y-1.5">
                          {w.exercises.map((ex, exIdx) => (
                            <div key={ex.id} className="text-xs bg-stone-50/50 p-2 rounded-xl border border-stone-100">
                              <div className="flex justify-between text-stone-700 font-semibold mb-1">
                                <span>{exIdx+1}. {ex.name}</span>
                                <span className="font-mono text-[10px] text-purple-600 uppercase font-medium">{ex.targetMuscle}</span>
                              </div>
                              <div className="flex flex-wrap gap-2 text-stone-500 text-[10px] font-mono">
                                {ex.sets.map((s, sIdx) => (
                                  <span key={s.id} className="bg-white px-1.5 py-0.5 rounded border border-stone-200/50">
                                    S{sIdx+1}: {s.reps}r × {s.weightKg}kg
                                  </span>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2 mt-4">
                        <span className="text-[10px] text-stone-400 font-mono block">Performance Metrics:</span>
                        <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-stone-50/50 p-2.5 rounded-xl border border-stone-100 text-stone-600">
                          <div>
                            Pace: <span className="font-semibold text-stone-800">{w.pacePerKm} /km</span>
                          </div>
                          <div>
                            Terrain: <span className="capitalize font-semibold text-stone-800">{w.routeType}</span>
                          </div>
                          {w.elevationGainM !== undefined && (
                            <div>
                              Elevation: <span className="font-semibold text-stone-800">+{w.elevationGainM}m</span>
                            </div>
                          )}
                          {w.averageHeartRate !== undefined && (
                            <div>
                              Avg HR: <span className="font-semibold text-stone-800">{w.averageHeartRate} BPM</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Notes bottom bar */}
                  {w.notes && (
                    <div className="mt-4 pt-3 border-t border-stone-100 text-xs italic text-stone-400 font-sans">
                      "{w.notes}"
                    </div>
                  )}

                </div>
              ))}
            </div>
          )}

        </div>
      )}

    </div>
  );
}
