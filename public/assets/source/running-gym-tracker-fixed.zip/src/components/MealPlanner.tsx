/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  UtensilsCrossed, 
  Smile, 
  Check, 
  Sparkles, 
  Info, 
  Bookmark,
  TrendingDown
} from 'lucide-react';
import { Meal, FoodItem, MealTime } from '../types';

interface MealPlannerProps {
  meals: Meal[];
  dailyCalorieGoal: number;
  onAddMeal: (meal: Meal) => void;
  onToggleMealCompleted: (id: string) => void;
  onDeleteMeal: (id: string) => void;
}

// Preset templates to choose or copy from
const PRESET_MEALS = [
  {
    name: 'Endurance Oatmeal Booster',
    mealTime: 'breakfast' as MealTime,
    items: [
      { id: 'p1', name: 'Organic Steel Oats', calories: 240, proteinG: 8, carbsG: 45, fatG: 4, servingSize: '70g' },
      { id: 'p2', name: 'Whey Protein Powder', calories: 120, proteinG: 26, carbsG: 2, fatG: 1, servingSize: '1 scoop' },
      { id: 'p3', name: 'Chia Seeds & Honey', calories: 95, proteinG: 2, carbsG: 16, fatG: 4, servingSize: '2 tbsp' }
    ]
  },
  {
    name: 'Lean Body Avocado Bowl',
    mealTime: 'lunch' as MealTime,
    items: [
      { id: 'p4', name: 'Grilled Chicken Breast', calories: 250, proteinG: 45, carbsG: 0, fatG: 5, servingSize: '150g' },
      { id: 'p5', name: 'Brown Rice & Spinach', calories: 180, proteinG: 5, carbsG: 34, fatG: 2, servingSize: '1 cup' },
      { id: 'p6', name: 'Fresh Avocado Rings', calories: 130, proteinG: 1, carbsG: 6, fatG: 12, servingSize: '1/2 piece' }
    ]
  },
  {
    name: 'Heart-Healthy Salmon Dinner',
    mealTime: 'dinner' as MealTime,
    items: [
      { id: 'p7', name: 'Baked Salmon Steak', calories: 310, proteinG: 32, carbsG: 0, fatG: 17, servingSize: '140g' },
      { id: 'p8', name: 'Mashed Sweet Potatoes', calories: 160, proteinG: 3, carbsG: 36, fatG: 1, servingSize: '180g' },
      { id: 'p9', name: 'Asparagus & Olive oil', calories: 60, proteinG: 2, carbsG: 5, fatG: 4, servingSize: '1 plate' }
    ]
  },
  {
    name: 'High Protein Post-Gym Snack',
    mealTime: 'snack' as MealTime,
    items: [
      { id: 'p10', name: 'Double-Strained Greek Yogurt', calories: 130, proteinG: 17, carbsG: 6, fatG: 3, servingSize: '150g' },
      { id: 'p11', name: 'Unsalted Handful Almonds', calories: 160, proteinG: 6, carbsG: 6, fatG: 14, servingSize: '25g' }
    ]
  }
];

export default function MealPlanner({
  meals,
  dailyCalorieGoal,
  onAddMeal,
  onToggleMealCompleted,
  onDeleteMeal,
}: MealPlannerProps) {
  // Navigation
  const [selectedMealtimeFilter, setSelectedMealtimeFilter] = useState<'all' | MealTime>('all');
  
  // Custom Food Logger
  const [showCustomForm, setShowCustomForm] = useState(false);
  const [customMealtime, setCustomMealtime] = useState<MealTime>('breakfast');
  const [customMealName, setCustomMealName] = useState('My Customized Balanced Plate');
  
  // Dynamic list of items being entered in the custom logger
  const [loggedItems, setLoggedItems] = useState<Omit<FoodItem, 'id'>[]>([
    { name: 'Brown Rice', calories: 150, proteinG: 4, carbsG: 30, fatG: 2, servingSize: '100g' }
  ]);

  // Temporary row logger
  const [tempItemName, setTempItemName] = useState('');
  const [tempItemCal, setTempItemCal] = useState('120');
  const [tempItemProt, setTempItemProt] = useState('20');
  const [tempItemCarbs, setTempItemCarbs] = useState('5');
  const [tempItemFat, setTempItemFat] = useState('1');
  const [tempItemSize, setTempItemSize] = useState('100g');

  const handleAddTempItem = () => {
    if (!tempItemName) return;
    setLoggedItems([
      ...loggedItems,
      {
        name: tempItemName,
        calories: Math.max(0, parseInt(tempItemCal) || 0),
        proteinG: Math.max(0, parseInt(tempItemProt) || 0),
        carbsG: Math.max(0, parseInt(tempItemCarbs) || 0),
        fatG: Math.max(0, parseInt(tempItemFat) || 0),
        servingSize: tempItemSize || '1 portion',
      }
    ]);
    setTempItemName('');
  };

  const handleRemoveItem = (index: number) => {
    setLoggedItems(loggedItems.filter((_, idx) => idx !== index));
  };

  const handleSubmitCustomMeal = (e: React.FormEvent) => {
    e.preventDefault();
    if (loggedItems.length === 0) return;

    const uniqueItems: FoodItem[] = loggedItems.map((item, idx) => ({
      ...item,
      id: `food-${Date.now()}-${idx}`
    }));

    const newMeal: Meal = {
      id: `meal-${Date.now()}`,
      mealTime: customMealtime,
      name: customMealName || 'Healthy Balanced meal',
      items: uniqueItems,
      isCompleted: true,
      notes: 'Custom food items logged securely'
    };

    onAddMeal(newMeal);
    setShowCustomForm(false);
    
    // Reset templates
    setCustomMealName('My Customized Balanced Plate');
    setLoggedItems([{ name: 'Brown Rice', calories: 150, proteinG: 4, carbsG: 30, fatG: 2, servingSize: '100g' }]);
  };

  // Preset Fast Logger
  const handleFastLoggerPreset = (preset: typeof PRESET_MEALS[0]) => {
    const itemsWithIds: FoodItem[] = preset.items.map((item, idx) => ({
      ...item,
      id: `food-preset-${Date.now()}-${idx}`
    }));

    const newMeal: Meal = {
      id: `meal-preset-${Date.now()}`,
      mealTime: preset.mealTime,
      name: preset.name,
      items: itemsWithIds,
      isCompleted: true,
      notes: 'Logged instantly via preset templates'
    };

    onAddMeal(newMeal);
  };

  // Calculations
  const calculatedMacros = meals.reduce((acc, currentMeal) => {
    currentMeal.items.forEach(item => {
      acc.calories += item.calories;
      acc.protein += item.proteinG;
      acc.carbs += item.carbsG;
      acc.fat += item.fatG;
    });
    return acc;
  }, { calories: 0, protein: 0, carbs: 0, fat: 0 });

  // Recommended Target splits based on calorie goal: e.g. Protein 30%, Carbs 45%, Fat 25%
  const targetProteinG = Math.round((dailyCalorieGoal * 0.3) / 4);
  const targetCarbsG = Math.round((dailyCalorieGoal * 0.45) / 4);
  const targetFatG = Math.round((dailyCalorieGoal * 0.25) / 9);

  const protPct = Math.min(100, Math.round((calculatedMacros.protein / targetProteinG) * 100));
  const carbsPct = Math.min(100, Math.round((calculatedMacros.carbs / targetCarbsG) * 100));
  const fatPct = Math.min(100, Math.round((calculatedMacros.fat / targetFatG) * 100));
  const caloriePct = Math.min(100, Math.round((calculatedMacros.calories / dailyCalorieGoal) * 100));

  const filteredMeals = meals.filter(m => selectedMealtimeFilter === 'all' || m.mealTime === selectedMealtimeFilter);

  return (
    <div className="space-y-8">
      
      {/* Top Banner with Macro rings */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left macro analysis metrics */}
        <div className="col-span-1 lg:col-span-8 bg-white border border-stone-100 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex justify-between items-center mb-2">
            <div>
              <h3 className="text-lg font-light tracking-tight text-stone-800">Macro Target Alignment</h3>
              <p className="text-xs text-stone-400 mt-1">Based on standard active split targets derived from calorie settings</p>
            </div>
            <span className="text-xs font-mono bg-purple-50 text-purple-600 px-3 py-1 rounded-full border border-purple-100">
              Interactive Energy Tracker
            </span>
          </div>

          {/* Calorie Bar progress */}
          <div>
            <div className="flex justify-between items-center text-xs font-mono font-medium mb-1.5">
              <span className="text-stone-500">Intake Accumulation: {calculatedMacros.calories} kcal</span>
              <span className="text-stone-400">Target: {dailyCalorieGoal} kcal</span>
            </div>
            <div className="w-full bg-stone-100 h-3 rounded-full overflow-hidden">
              <div 
                className="bg-purple-300 h-full rounded-full transition-all duration-700 ease-out" 
                style={{ width: `${caloriePct}%` }}
              />
            </div>
            <div className="flex justify-between mt-1 text-[10px] text-stone-400 font-mono">
              <span>{caloriePct}% tracked</span>
              <span>{Math.max(0, dailyCalorieGoal - calculatedMacros.calories)} kcal remaining</span>
            </div>
          </div>

          {/* Individual macro indicators */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-stone-100">
            {/* Protein Card */}
            <div className="bg-[#fff1f2]/40 border border-rose-100/50 p-4 rounded-2xl">
              <span className="text-[10px] uppercase font-mono tracking-widest text-rose-500 block mb-1">Protein</span>
              <h4 className="text-lg font-semibold text-stone-800 font-display">
                {calculatedMacros.protein}g <span className="text-xs text-stone-400 font-normal">/ {targetProteinG}g</span>
              </h4>
              <div className="w-full bg-rose-100 h-1 rounded-full mt-2 overflow-hidden">
                <div className="bg-rose-400 h-full rounded-full" style={{ width: `${protPct}%` }} />
              </div>
              <span className="text-[10px] font-mono text-stone-400 block mt-1">{protPct}% met</span>
            </div>

            {/* Carbs Card */}
            <div className="bg-[#f0f9ff]/40 border border-blue-105 p-4 rounded-2xl">
              <span className="text-[10px] uppercase font-mono tracking-widest text-sky-500 block mb-1">Carbohydrates</span>
              <h4 className="text-lg font-semibold text-stone-800 font-display">
                {calculatedMacros.carbs}g <span className="text-xs text-stone-400 font-normal">/ {targetCarbsG}g</span>
              </h4>
              <div className="w-full bg-blue-100 h-1 rounded-full mt-2 overflow-hidden">
                <div className="bg-sky-400 h-full rounded-full" style={{ width: `${carbsPct}%` }} />
              </div>
              <span className="text-[10px] font-mono text-stone-400 block mt-1">{carbsPct}% met</span>
            </div>

            {/* Fats Card */}
            <div className="bg-[#fff7ed]/50 border border-amber-100 p-4 rounded-2xl">
              <span className="text-[10px] uppercase font-mono tracking-widest text-amber-500 block mb-1">Fats</span>
              <h4 className="text-lg font-semibold text-stone-800 font-display">
                {calculatedMacros.fat}g <span className="text-xs text-stone-400 font-normal">/ {targetFatG}g</span>
              </h4>
              <div className="w-full bg-amber-100 h-1 rounded-full mt-2 overflow-hidden">
                <div className="bg-amber-400 h-full rounded-full" style={{ width: `${fatPct}%` }} />
              </div>
              <span className="text-[10px] font-mono text-stone-400 block mt-1">{fatPct}% met</span>
            </div>
          </div>

          <div className="bg-stone-50 border border-stone-200/50 p-3.5 rounded-xl flex items-center gap-3 text-xs text-stone-600">
            <Info className="w-4 h-4 text-purple-400 flex-shrink-0" />
            <p>
              Diet metrics sync in real-time. Feel free to adjust daily calorie limits inside the <strong>"Adjust Targets"</strong> panel above as needed.
            </p>
          </div>
        </div>

        {/* Right column: Preset Templates Fast-logs */}
        <div className="col-span-1 lg:col-span-4 bg-[#faf5ff]/40 border border-purple-100 p-6 rounded-3xl space-y-4">
          <div className="flex items-center gap-2 text-purple-85px font-medium mb-1">
            <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
            <h4 className="text-sm uppercase tracking-wider font-display font-semibold text-purple-700">Aesthetic Recipes Fast-log</h4>
          </div>
          <p className="text-xs text-stone-400 mb-2">Instantly attach nutrient-dense healthy blueprints to today's schedule:</p>
          
          <div className="space-y-3">
            {PRESET_MEALS.map((preset, idx) => (
              <div 
                key={idx} 
                className="bg-white hover:bg-stone-50 border border-stone-200/40 p-3 rounded-2xl flex justify-between items-center transition shadow-xs group"
              >
                <div>
                  <span className="text-[9px] font-mono uppercase bg-purple-50 text-purple-600 font-semibold px-2 py-0.5 rounded-full">
                    {preset.mealTime}
                  </span>
                  <p className="text-xs font-semibold text-stone-700 tracking-tight mt-1">{preset.name}</p>
                  <p className="text-[10px] text-stone-400 font-mono mt-0.5">
                    {preset.items.reduce((sum, item) => sum + item.calories, 0)} kcal · Protein {preset.items.reduce((sum, item) => sum + item.proteinG, 0)}g
                  </p>
                </div>
                
                <button
                  onClick={() => handleFastLoggerPreset(preset)}
                  className="p-1 px-2.5 bg-purple-100 hover:bg-purple-200 text-purple-700 rounded-full text-[10px] font-semibold tracking-tight transition cursor-pointer"
                  title="Log preset"
                >
                  Log
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Meals Filters and Add Log Button */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-stone-50 border border-stone-100 p-3 rounded-2xl" id="mealtime-filters-bar">
        <div className="flex bg-white p-1 border border-stone-200/60 rounded-xl gap-0.5">
          {(['all', 'breakfast', 'lunch', 'dinner', 'snack'] as const).map(time => (
            <button
              key={time}
              onClick={() => setSelectedMealtimeFilter(time)}
              className={`px-3 py-1 rounded-lg text-xs font-medium uppercase font-mono tracking-tight transition-all cursor-pointer ${
                selectedMealtimeFilter === time 
                  ? 'bg-stone-900 text-white shadow-xs' 
                  : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              {time}
            </button>
          ))}
        </div>

        <button 
          onClick={() => setShowCustomForm(!showCustomForm)}
          className="flex items-center gap-1.5 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-medium tracking-tight transition-colors cursor-pointer"
          id="custom-meal-modal-btn"
        >
          <Plus className="w-4 h-4" />
          Custom Foods Log
        </button>
      </div>

      {/* Modal/Form Overlay for Custom Food Log */}
      {showCustomForm && (
        <div className="fixed inset-0 z-50 bg-stone-900/10 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 md:p-8 max-w-2xl w-full border border-stone-100 shadow-xl overflow-y-auto max-h-[85vh] transition-all">
            
            <div className="flex justify-between items-center mb-6 border-b border-stone-100 pb-4">
              <div>
                <h3 className="text-lg font-light text-stone-800 tracking-tight">Detail Your Nutrition Plate</h3>
                <p className="text-xs text-stone-400">Log custom recipes and ingredient breakdowns</p>
              </div>
              <button 
                onClick={() => setShowCustomForm(false)}
                className="p-1.5 rounded-full hover:bg-stone-50 text-stone-400"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleSubmitCustomMeal} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-stone-500 mb-1">Meal category</label>
                  <select 
                    value={customMealtime}
                    onChange={e => setCustomMealtime(e.target.value as MealTime)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  >
                    <option value="breakfast">Breakfast</option>
                    <option value="lunch">Lunch</option>
                    <option value="dinner">Dinner</option>
                    <option value="snack">Snack Portion</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">Meal Title / Description</label>
                  <input 
                    type="text" 
                    value={customMealName}
                    onChange={e => setCustomMealName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:outline-none"
                    placeholder="Plate custom description"
                    required
                  />
                </div>
              </div>

              {/* Logged sub items */}
              <div className="space-y-3 pt-3 border-t border-stone-100">
                <span className="text-xs font-mono uppercase tracking-wider text-stone-400 block">Logged Ingredient Rows</span>
                
                {loggedItems.length === 0 ? (
                  <p className="text-xs text-stone-400 italic py-2 text-center">Add at least one food row below to finalize validation</p>
                ) : (
                  <div className="space-y-2">
                    {loggedItems.map((item, index) => (
                      <div key={index} className="flex items-center justify-between text-xs bg-[#fafaf9] p-3 border border-stone-200/50 rounded-xl">
                        <div>
                          <span className="font-semibold text-stone-800">{item.name}</span>
                          <span className="text-stone-400 text-[10px] ml-2">({item.servingSize})</span>
                        </div>
                        <div className="flex items-center gap-4 text-stone-500 font-mono text-[11px]">
                          <span>{item.calories} kcal</span>
                          <span>P:{item.proteinG}g C:{item.carbsG}g F:{item.fatG}g</span>
                          <button 
                            type="button" 
                            onClick={() => handleRemoveItem(index)}
                            className="text-stone-300 hover:text-rose-500 p-0.5"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Sub items temporary entry row */}
              <div className="p-4 bg-stone-50 border border-stone-200/60 rounded-2xl space-y-3">
                <span className="text-xs font-medium text-stone-600 block">Row Ingredient Configurator</span>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="col-span-2 sm:col-span-1">
                    <label className="block text-[10px] text-stone-400 uppercase tracking-widest mb-0.5">Ingredient Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Avocado" 
                      value={tempItemName}
                      onChange={e => setTempItemName(e.target.value)}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 uppercase tracking-widest mb-0.5">Serving Size</label>
                    <input 
                      type="text" 
                      placeholder="e.g. 100g, 1 cup" 
                      value={tempItemSize}
                      onChange={e => setTempItemSize(e.target.value)}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 uppercase tracking-widest mb-0.5">Calories (kcal)</label>
                    <input 
                      type="number" 
                      value={tempItemCal}
                      onChange={e => setTempItemCal(e.target.value)}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 pt-1">
                  <div>
                    <label className="block text-[10px] text-stone-400 uppercase tracking-widest mb-0.5">Protein (g)</label>
                    <input 
                      type="number" 
                      value={tempItemProt}
                      onChange={e => setTempItemProt(e.target.value)}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 uppercase tracking-widest mb-0.5">Carbs (g)</label>
                    <input 
                      type="number" 
                      value={tempItemCarbs}
                      onChange={e => setTempItemCarbs(e.target.value)}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 uppercase tracking-widest mb-0.5">Fat (g)</label>
                    <input 
                      type="number" 
                      value={tempItemFat}
                      onChange={e => setTempItemFat(e.target.value)}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleAddTempItem}
                  className="w-full py-1.5 bg-stone-200 hover:bg-stone-300 rounded-xl text-xs font-semibold text-stone-75px transition flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Attach Ingredient Row
                </button>
              </div>

              <div className="flex gap-4 pt-4 border-t border-stone-100">
                <button 
                  type="button" 
                  onClick={() => setShowCustomForm(false)}
                  className="flex-1 px-4 py-2 bg-stone-100 text-stone-600 rounded-xl text-xs font-semibold"
                >
                  Discard Changes
                </button>
                <button 
                  type="submit" 
                  disabled={loggedItems.length === 0}
                  className="flex-1 px-4 py-2 bg-stone-900 text-white rounded-xl text-xs font-semibold hover:bg-stone-800 disabled:opacity-50"
                  id="save-custom-meal-btn"
                >
                  Attach Meal Block
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Active Scheduled Meals Plate list */}
      {filteredMeals.length === 0 ? (
        <div className="bg-white border border-dashed border-stone-200 rounded-3xl text-center py-12">
          <UtensilsCrossed className="w-10 h-10 text-stone-300 mx-auto mb-3" />
          <p className="text-sm font-medium text-stone-500">No meal schedules recorded matching chosen filters</p>
          <p className="text-xs text-stone-400 mt-1">Touch fast-log recipes above or create custom ingredient logs to align macros</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredMeals.map(meal => {
            const mealCalories = meal.items.reduce((sum, item) => sum + item.calories, 0);
            const mealProtein = meal.items.reduce((sum, item) => sum + item.proteinG, 0);
            const mealCarbs = meal.items.reduce((sum, item) => sum + item.carbsG, 0);
            const mealFat = meal.items.reduce((sum, item) => sum + item.fatG, 0);

            return (
              <div 
                key={meal.id} 
                className="bg-white border border-stone-100 rounded-3xl p-5 hover:shadow-xs transition flex flex-col justify-between"
                id={`meal-row-${meal.id}`}
              >
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <span className="text-[9px] uppercase font-mono tracking-widest bg-stone-100 text-stone-500 px-2.5 py-0.5 rounded-full font-bold">
                        {meal.mealTime}
                      </span>
                      <h4 className="text-sm font-semibold text-stone-800 font-display mt-2">{meal.name}</h4>
                    </div>
                    
                    <div className="flex items-center gap-1.5">
                      <button 
                        onClick={() => onToggleMealCompleted(meal.id)}
                        className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                          meal.isCompleted 
                            ? 'bg-emerald-100 text-emerald-600 border border-emerald-300' 
                            : 'bg-white border border-stone-300 text-stone-400'
                        }`}
                        title="Completed eaten status"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>

                      <button 
                        onClick={() => onDeleteMeal(meal.id)}
                        className="p-1 rounded text-stone-300 hover:text-red-500 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Food items logs list */}
                  <div className="space-y-1.5 my-4 border-t border-b border-stone-50 py-3">
                    {meal.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-xs text-stone-600">
                        <span>{it.name} <span className="text-[10px] text-stone-400">({it.servingSize})</span></span>
                        <span className="font-mono text-stone-500">{it.calories} kcal</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Macro summary footer */}
                <div className="flex justify-between items-center bg-stone-50 -mx-5 -mb-5 p-4 rounded-b-3xl mt-2 text-xs font-mono">
                  <div className="text-stone-500">
                    Total: <span className="text-stone-800 font-semibold">{mealCalories} kcal</span>
                  </div>
                  <div className="text-[10px] text-stone-400">
                    P: {mealProtein}g · C: {mealCarbs}g · F: {mealFat}g
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
