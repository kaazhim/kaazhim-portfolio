import React, { useState, useEffect } from 'react';
import { Music, RefreshCw, Zap, Headphones, CheckCircle2, Play, Pause, SkipForward, SkipBack } from 'lucide-react';
import { Workout, Meal } from '../types';

interface SpotifyIntegrationPanelProps {
  workouts: Workout[];
  meals: Meal[];
}

export default function SpotifyIntegrationPanel({ workouts, meals }: SpotifyIntegrationPanelProps) {
  const [accessToken, setAccessToken] = useState<string | null>(localStorage.getItem('spotify_access_token'));
  const [profile, setProfile] = useState<any>(null);
  const [recentTracks, setRecentTracks] = useState<any[]>([]);
  const [nowPlaying, setNowPlaying] = useState<any>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [geminiSuggestion, setGeminiSuggestion] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    // Listen for the OAuth message from the popup
    const handleMessage = (event: MessageEvent) => {
      // Validate origin to ensure it's from our app
      if (!event.origin.endsWith('.run.app') && !event.origin.includes('localhost')) {
        return;
      }
      
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        const { access_token } = event.data.payload;
        setAccessToken(access_token);
        localStorage.setItem('spotify_access_token', access_token);
        setIsConnecting(false);
      }
    };
    
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  useEffect(() => {
    if (accessToken) {
      fetchSpotifyData(accessToken);
      // Poll now playing every 10 seconds
      const pollInterval = setInterval(() => fetchNowPlaying(accessToken), 10000);
      return () => clearInterval(pollInterval);
    }
  }, [accessToken]);

  const handleConnect = async () => {
    try {
      setIsConnecting(true);
      const res = await fetch('/api/auth/spotify/url');
      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || 'Failed to get auth URL');
      }
      
      const authWindow = window.open(data.url, 'spotify_oauth', 'width=600,height=700');
      if (!authWindow) {
        alert('Please allow popups for this site to connect your Spotify account.');
        setIsConnecting(false);
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Make sure you added SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET to the secrets panel.');
      setIsConnecting(false);
    }
  };

  const fetchNowPlaying = async (token: string) => {
    try {
      const res = await fetch('/api/spotify/now-playing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken: token })
      });
      if (res.ok) {
        const data = await res.json();
        setNowPlaying(data.isPlaying === false ? null : data);
      }
    } catch (e) {
      console.error("Failed to load now playing", e);
    }
  };

  const fetchSpotifyData = async (token: string) => {
    try {
      // Fetch Profile
      const pRes = await fetch('/api/spotify/me', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken: token })
      });
      if (pRes.ok) setProfile(await pRes.json());
      
      // Fetch Recent Tracks
      const trRes = await fetch('/api/spotify/recent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken: token })
      });
      if (trRes.ok) setRecentTracks(await trRes.json());
      
      await fetchNowPlaying(token);
    } catch (e) {
      console.error("Failed to load spotify data", e);
    }
  };

  const handlePlaybackControl = async (action: 'play' | 'pause' | 'next' | 'previous') => {
    if (!accessToken) return;
    
    // Optimistic UI updates
    if (nowPlaying) {
      if (action === 'play') setNowPlaying({ ...nowPlaying, is_playing: true });
      if (action === 'pause') setNowPlaying({ ...nowPlaying, is_playing: false });
    }
    
    try {
      await fetch('/api/spotify/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken, action })
      });
      // Re-fetch after a short delay to account for Spotify API latency
      setTimeout(() => fetchNowPlaying(accessToken), 1000);
    } catch (e) {
      console.error(`Failed to ${action}`, e);
    }
  };

  const handleDisconnect = () => {
    setAccessToken(null);
    setProfile(null);
    setRecentTracks([]);
    setNowPlaying(null);
    setGeminiSuggestion('');
    localStorage.removeItem('spotify_access_token');
  };

  const analyzeVibe = async () => {
    setIsAnalyzing(true);
    try {
      const recentWorkouts = workouts.slice(0, 3);
      const recentArtists = recentTracks.map(t => t.track.artists[0]?.name).filter(Boolean);

      const res = await fetch('/api/gemini/analyze-vibe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workouts: recentWorkouts,
          recentArtists
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setGeminiSuggestion(data.text);
    } catch (e: any) {
      console.error(e);
      alert(e.message || "Failed to analyze vibe using Gemini.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-md border border-stone-200/60 rounded-3xl p-6 shadow-sm mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="bg-[#1DB954]/10 p-3 rounded-2xl">
            <Music className="w-5 h-5 text-[#1DB954]" />
          </div>
          <div>
            <h3 className="text-xl font-semibold tracking-tight text-stone-850">Spotify Smart Sync</h3>
            <p className="text-xs text-stone-500 mt-0.5">Integrate your music profile into Aura Active</p>
          </div>
        </div>
        {!accessToken ? (
          <button 
            onClick={handleConnect}
            disabled={isConnecting}
            className="flex items-center gap-2 bg-[#1DB954] text-white px-4 py-2 rounded-full font-semibold text-sm hover:bg-[#1ed760] transition-colors cursor-pointer"
          >
            {isConnecting ? <RefreshCw className="w-4 h-4 animate-spin" /> : "Connect Spotify"}
          </button>
        ) : (
          <button 
            onClick={handleDisconnect}
            className="text-xs text-stone-400 hover:text-rose-500 transition-colors cursor-pointer font-medium"
          >
            Disconnect Account
          </button>
        )}
      </div>

      {accessToken && profile && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* Main User Profile & Now Playing */}
          <div className="lg:col-span-1 bg-stone-50 rounded-2xl p-4 border border-stone-100 flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                {profile.images?.[0] ? (
                  <img src={profile.images[0].url} alt="Profile" className="w-10 h-10 rounded-full object-cover shadow-sm" />
                ) : (
                  <div className="w-10 h-10 bg-stone-200 rounded-full flex items-center justify-center">
                    <Headphones className="w-5 h-5 text-stone-400" />
                  </div>
                )}
                <div>
                  <h4 className="font-semibold text-stone-850 text-sm">{profile.display_name}</h4>
                  <p className="text-[10px] text-[#1DB954] font-medium flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> Connected</p>
                </div>
              </div>
            </div>

            {nowPlaying && nowPlaying.item ? (
              <div className="mt-auto bg-white p-3 rounded-xl shadow-xs border border-stone-100">
                <div className="flex items-center gap-3 mb-3">
                  {nowPlaying.item.album?.images?.[0] ? (
                    <img src={nowPlaying.item.album.images[0].url} className="w-12 h-12 rounded-lg shadow-sm" alt="Album" />
                  ) : (
                    <div className="w-12 h-12 bg-stone-100 rounded-lg flex items-center justify-center">
                      <Music className="w-5 h-5 text-stone-400" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h5 className="text-[#1DB954] text-[9px] uppercase font-bold tracking-wider mb-0.5 flex items-center gap-1">
                      <span className={`w-1.5 h-1.5 bg-[#1DB954] rounded-full ${nowPlaying.is_playing ? 'animate-pulse' : ''}`}></span> 
                      {nowPlaying.is_playing ? 'Now Playing' : 'Paused'}
                    </h5>
                    <div className="text-sm font-bold text-stone-800 truncate">{nowPlaying.item.name}</div>
                    <div className="text-[10px] text-stone-500 truncate">{nowPlaying.item.artists?.map((a: any) => a.name).join(', ')}</div>
                  </div>
                </div>
                
                <div className="flex items-center justify-center gap-4 mt-2">
                  <button onClick={() => handlePlaybackControl('previous')} className="text-stone-400 hover:text-stone-700 transition-colors p-1 cursor-pointer">
                    <SkipBack className="w-4 h-4 fill-current" />
                  </button>
                  {nowPlaying.is_playing ? (
                    <button onClick={() => handlePlaybackControl('pause')} className="bg-stone-800 text-white p-2 rounded-full hover:bg-stone-700 transition-colors cursor-pointer shadow-md">
                      <Pause className="w-4 h-4 fill-current" />
                    </button>
                  ) : (
                    <button onClick={() => handlePlaybackControl('play')} className="bg-[#1DB954] text-white p-2 rounded-full hover:bg-[#1ed760] transition-colors cursor-pointer shadow-md">
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    </button>
                  )}
                  <button onClick={() => handlePlaybackControl('next')} className="text-stone-400 hover:text-stone-700 transition-colors p-1 cursor-pointer">
                    <SkipForward className="w-4 h-4 fill-current" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-auto bg-white p-4 rounded-xl shadow-xs border border-stone-100 text-center flex flex-col items-center justify-center border-dashed">
                <Headphones className="w-6 h-6 text-stone-300 mb-2" />
                <p className="text-xs text-stone-500 font-medium">Nothing is playing right now.</p>
                <p className="text-[10px] text-stone-400 mt-1">Open Spotify to start playing</p>
              </div>
            )}
          </div>

          {/* Gemini AI Vibe */}
          <div className="lg:col-span-2 bg-gradient-to-tr from-purple-50 to-pink-50 rounded-2xl p-5 border border-purple-100 flex flex-col justify-between relative overflow-hidden">
            <Zap className="absolute top-[-10px] right-[-10px] w-24 h-24 text-purple-200/50 -rotate-12" />
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-bold text-purple-700 tracking-tight flex items-center gap-1.5">
                    <Zap className="w-4 h-4 fill-purple-700 text-purple-700" /> AI Vibe Coach
                  </h4>
                  <p className="text-xs text-purple-600/70 mt-1">Gemini Pro analyzes your fitness data to construct the ultimate soundtrack.</p>
                </div>
              </div>
              
              {geminiSuggestion ? (
                <div className="bg-white/70 p-4 rounded-xl border border-white/60 text-sm italic text-stone-700 shadow-xs leading-relaxed whitespace-pre-wrap">
                  "{geminiSuggestion}"
                </div>
              ) : (
                <div className="h-28 flex flex-col justify-center items-center py-4 bg-white/40 rounded-xl border border-white/50 border-dashed">
                  <span className="text-xs flex items-center gap-2 text-purple-500 mb-3 font-mono font-medium">
                    <Zap className="w-3.5 h-3.5" /> Awaiting Input Signals
                  </span>
                  <button 
                    onClick={analyzeVibe}
                    disabled={isAnalyzing}
                    className="bg-purple-600 text-white px-5 py-2 rounded-full text-xs font-semibold hover:bg-purple-500 transition-colors shadow-sm cursor-pointer flex items-center gap-1.5"
                  >
                    {isAnalyzing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : "Initiate Vibe Analysis"}
                  </button>
                </div>
              )}
            </div>
            
            {geminiSuggestion && (
              <div className="relative z-10 mt-4 flex justify-end">
                <button onClick={analyzeVibe} disabled={isAnalyzing} className="text-[10px] uppercase font-mono tracking-wider text-purple-500 hover:text-purple-700 font-bold flex items-center gap-1.5 cursor-pointer bg-white/50 px-3 py-1.5 rounded-full hover:bg-white/80 transition-colors">
                  {isAnalyzing ? "Processing..." : "Re-Roll Analysis"} <RefreshCw className={`w-3 h-3 ${isAnalyzing ? 'animate-spin' : ''}`} />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
