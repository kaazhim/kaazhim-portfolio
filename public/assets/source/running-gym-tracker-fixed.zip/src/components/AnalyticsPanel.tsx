/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  TrendingUp, 
  Dumbbell, 
  Compass, 
  Award, 
  Zap, 
  Activity, 
  BarChart2, 
  Info,
  ChevronRight,
  Check,
  Download,
  FileText,
  Plus,
  Scale,
  Printer,
  X,
  TrendingDown,
  Calendar
} from 'lucide-react';
import { Workout, DailyMetrics, Meal, UserGoals } from '../types';
import { motion } from 'motion/react';

interface AnalyticsPanelProps {
  workouts: Workout[];
  metrics: DailyMetrics[];
  meals?: Meal[];
  goals?: UserGoals;
  onUpdateWeight?: (weightKg: number) => void;
}

export default function AnalyticsPanel({ 
  workouts, 
  metrics, 
  meals = [], 
  goals = { dailyWaterMl: 2500, dailyCaloriesBurned: 600, dailyCalorieIntake: 2200, weeklyRunningDistanceKm: 25, weeklyGymWorkouts: 4 }, 
  onUpdateWeight 
}: AnalyticsPanelProps) {
  const [selectedChartRange, setSelectedChartRange] = useState<'7days' | 'all'>('7days');
  const [weightInput, setWeightInput] = useState('');
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [weightFormStatus, setWeightFormStatus] = useState<'idle' | 'saved'>('idle');

  // Generate date ranges for past 7 days
  const getPastDatesList = (numDays: number): string[] => {
    const list = [];
    for (let i = numDays - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      list.push(d.toISOString().split('T')[0]);
    }
    return list;
  };

  const last7Days = getPastDatesList(7);

  // Group running data by date
  const runDataMap = last7Days.map(dateStr => {
    const dayRuns = workouts.filter(w => w.date === dateStr && w.type === 'running' && w.isCompleted) as any[];
    const distanceKm = dayRuns.reduce((sum, r) => sum + (r.distanceKm || 0), 0);
    const duration = dayRuns.reduce((sum, r) => sum + (r.durationMinutes || 0), 0);
    
    const d = new Date(dateStr);
    const label = d.toLocaleDateString('en-US', { weekday: 'short' });
    
    return { date: dateStr, label, distanceKm, duration };
  });

  // Group gym sets volume by date
  const gymDataMap = last7Days.map(dateStr => {
    const dayGym = workouts.filter(w => w.date === dateStr && w.type === 'gym' && w.isCompleted) as any[];
    
    let totalSetsNum = 0;
    dayGym.forEach(g => {
      g.exercises.forEach((ex: any) => {
        totalSetsNum += ex.sets.length;
      });
    });

    const d = new Date(dateStr);
    const label = d.toLocaleDateString('en-US', { weekday: 'short' });

    return { date: dateStr, label, setsCompleted: totalSetsNum, workoutsCount: dayGym.length };
  });

  // 1. PAST 30 DAYS WEIGHT TRACKING DATAPOINTS
  const past30DaysList = getPastDatesList(30);
  
  // Find continuous weight trends. If a day has no logged weight, fall back to last known weight.
  let currentEstimatedWeight = 78.4; // standard baseline setup
  // Safely find the first logged weight in real history if it exists
  const firstLogged = metrics.find(m => m.weightKg !== undefined && m.weightKg > 0);
  if (firstLogged && firstLogged.weightKg) {
    currentEstimatedWeight = firstLogged.weightKg;
  }

  const weightData30 = past30DaysList.map(dateStr => {
    const match = metrics.find(m => m.date === dateStr);
    let targetWt = currentEstimatedWeight;
    if (match && match.weightKg && match.weightKg > 0) {
      targetWt = match.weightKg;
      currentEstimatedWeight = match.weightKg; // update estimated
    }
    const d = new Date(dateStr);
    const label = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    return { date: dateStr, label, weightKg: targetWt };
  });

  // Find overall weight trend stats
  const initialWeight = weightData30[0]?.weightKg || 78.4;
  const latestWeight = weightData30[weightData30.length - 1]?.weightKg || 78.4;
  const weightDiff = latestWeight - initialWeight;

  // Calculate high performance landmarks
  const totalGymWorkoutsCount = workouts.filter(w => w.type === 'gym').length;
  const totalRunningMileage = workouts.filter(w => w.type === 'running').reduce((sum, r) => sum + ((r as any).distanceKm || 0), 0);
  const totalActiveTime = workouts.reduce((sum, w) => sum + w.durationMinutes, 0);

  // SVG dimensions for running trend line
  const runChartWidth = 500;
  const runChartHeight = 160;
  const runPadding = 24;
  const maxRunKm = Math.max(...runDataMap.map(r => r.distanceKm), 4);
  
  const runPoints = runDataMap.map((data, idx) => {
    const x = runPadding + (idx * (runChartWidth - runPadding * 2)) / (runDataMap.length - 1);
    const y = runChartHeight - runPadding - (data.distanceKm / maxRunKm) * (runChartHeight - runPadding * 2);
    return { x, y, data };
  });

  const runPointsString = runPoints.map(p => `${p.x},${p.y}`).join(' ');
  const areaPointsString = `${runPadding},${runChartHeight - runPadding} ${runPointsString} ${runChartWidth - runPadding},${runChartHeight - runPadding}`;

  // SVG calculations for gym volume bar charts
  const gymChartWidth = 500;
  const gymChartHeight = 160;
  const gymPadding = 24;
  const maxGymSets = Math.max(...gymDataMap.map(g => g.setsCompleted), 8);
  const barWidth = 26;

  // SVG calculations for 30-day weight chart
  const weightChartWidth = 600;
  const weightChartHeight = 180;
  const weightPadding = 32;

  const weightsList = weightData30.map(w => w.weightKg);
  // Establish baseline bounds
  const minWt = Math.min(...weightsList, 65) - 1.5;
  const maxWt = Math.max(...weightsList, 85) + 1.5;
  const wtRange = maxWt - minWt;

  const weightPoints = weightData30.map((data, idx) => {
    const x = weightPadding + (idx * (weightChartWidth - weightPadding * 2)) / (weightData30.length - 1);
    const y = weightChartHeight - weightPadding - ((data.weightKg - minWt) / wtRange) * (weightChartHeight - weightPadding * 2);
    return { x, y, data };
  });

  const weightPointsString = weightPoints.map(p => `${p.x},${p.y}`).join(' ');
  const weightAreaPointsString = `${weightPadding},${weightChartHeight - weightPadding} ${weightPointsString} ${weightChartWidth - weightPadding},${weightChartHeight - weightPadding}`;

  // Export handlers
  const handleExportCSV = () => {
    let csv = 'Date,Weight (kg),Sleep (hrs),Water Intake (ml),Active Sweat (mins),Workouts Logged,Meals Caloric Intake\n';
    
    last7Days.forEach(date => {
      const metricObj = (metrics.find(m => m.date === date) || { date, activeMinutes: 0, waterIntakeMl: 0 }) as DailyMetrics;
      const weightVal = metricObj.weightKg || 'N/A';
      const sleepVal = metricObj.sleepHours || 'N/A';
      const waterVal = metricObj.waterIntakeMl || 0;
      const activeMinutes = metricObj.activeMinutes || 0;
      
      const dayWorkouts = workouts.filter(w => w.date === date && w.isCompleted);
      const workoutsSummary = dayWorkouts.map(w => w.type === 'gym' ? 'Gym strength session' : `Run (${(w as any).distanceKm || 0}km)`).join('; ') || 'No sessions';
      
      const isToday = date === last7Days[6];
      const totalCalories = isToday 
        ? meals.filter(m => m.isCompleted).reduce((acc, m) => acc + m.items.reduce((sum, item) => sum + item.calories, 0), 0)
        : 1850;

      csv += `${date},${weightVal},${sleepVal},${waterVal},${activeMinutes},"${workoutsSummary}",${totalCalories}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `AuraActive_Performance_Report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLogWeightToday = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(weightInput);
    if (!isNaN(parsed) && parsed > 0 && onUpdateWeight) {
      onUpdateWeight(parsed);
      setWeightInput('');
      setWeightFormStatus('saved');
      setTimeout(() => setWeightFormStatus('idle'), 3000);
    }
  };

  return (
    <div className="space-y-8" id="analytics-panel-root">
      
      {/* Dynamic Header section with PDF representation trigger */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-stone-150">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-widest text-stone-400">Activity Telemetry Logs</span>
          <h2 className="text-3xl font-light tracking-tight text-stone-850 mt-1">Stamina & Diet Reports</h2>
        </div>
        
        {/* Export Buttons Section */}
        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          <button 
            onClick={handleExportCSV}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-stone-50 hover:bg-stone-100 border border-stone-200/80 rounded-xl text-xs font-semibold text-stone-600 transition cursor-pointer"
            id="export-csv-metrics-btn"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV Metrics
          </button>
          
          <button 
            onClick={() => setShowPrintPreview(true)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
            id="print-pdf-report-btn"
          >
            <FileText className="w-3.5 h-3.5" />
            Print Performance PDF
          </button>
        </div>
      </div>

      {/* Overview stats landmark metrics ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        <div className="bg-white border border-stone-100 p-5 rounded-3xl shadow-xs" id="stat-landmark-mileage">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] uppercase font-mono tracking-wider text-stone-400">Total Run Distance</span>
            <Compass className="w-4 h-4 text-sky-400" />
          </div>
          <h3 className="text-2xl font-semibold tracking-tight text-stone-850 font-display">
            {totalRunningMileage.toFixed(1)} <span className="text-stone-400 text-xs font-normal font-sans">km</span>
          </h3>
          <span className="text-[10px] font-mono text-emerald-500 font-medium">All sessions completed</span>
        </div>

        <div className="bg-white border border-stone-100 p-5 rounded-3xl shadow-xs" id="stat-landmark-sessions">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] uppercase font-mono tracking-wider text-stone-400 font-sans">Strength Gym days</span>
            <Dumbbell className="w-4 h-4 text-purple-400" />
          </div>
          <h3 className="text-2xl font-semibold tracking-tight text-stone-850 font-display">
            {totalGymWorkoutsCount} <span className="text-stone-400 text-xs font-normal">logs</span>
          </h3>
          <span className="text-[10px] font-mono text-purple-500 font-medium">{workouts.filter(w => w.type === 'gym').reduce((sum, w) => sum + (w.type === 'gym' ? (w as any).exercises.length : 0), 0)} exercised movements</span>
        </div>

        <div className="bg-white border border-stone-100 p-5 rounded-3xl shadow-xs">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] uppercase font-mono tracking-wider text-stone-400">Active Sweat Time</span>
            <Activity className="w-4 h-4 text-rose-400" />
          </div>
          <h3 className="text-2xl font-semibold tracking-tight text-stone-850 font-display">
            {totalActiveTime} <span className="text-stone-400 text-xs font-normal font-sans">mins</span>
          </h3>
          <span className="text-[10px] font-mono text-rose-500">Avg {Math.round(totalActiveTime / (workouts.length || 1))}m / session</span>
        </div>

        <div className="bg-white border border-stone-100 p-5 rounded-3xl shadow-xs">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] uppercase font-mono tracking-wider text-stone-400">Daily Calorie Target</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-2xl font-semibold tracking-tight text-stone-850 font-display">
            {workouts.reduce((sum, w) => sum + w.caloriesBurned, 0)} <span className="text-stone-400 text-xs font-normal font-sans">kcal</span>
          </h3>
          <span className="text-[10px] font-mono text-amber-500">Cumulative active burn</span>
        </div>

      </div>

      {/* Main Weekly Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* RUNNING TRENDS LINE AREA SVG CHART WITH MOTION PATH */}
        <div className="bg-white border border-stone-100 p-6 rounded-3xl shadow-sm space-y-4" id="running-chart-wrapper">
          <div className="flex justify-between items-center">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-sky-500 font-bold bg-[#f0f9ff] px-2.5 py-0.5 rounded-full">Performance Curve</span>
              <h4 className="text-base font-semibold text-stone-800 tracking-tight mt-1.5">Running Distances Weekly Trend</h4>
            </div>
            <span className="text-xs font-mono text-stone-405">Max: {maxRunKm.toFixed(1)} km</span>
          </div>

          <div className="relative">
            <svg 
              viewBox={`0 0 ${runChartWidth} ${runChartHeight}`} 
              className="w-full h-auto overflow-visible select-none"
            >
              {/* Grid Background lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
                const y = runPadding + ratio * (runChartHeight - runPadding * 2);
                const valueVal = maxRunKm - ratio * maxRunKm;
                return (
                  <g key={i}>
                    <line 
                      x1={runPadding} 
                      y1={y} 
                      x2={runChartWidth - runPadding} 
                      y2={y} 
                      className="stroke-stone-100" 
                      strokeWidth={1} 
                      strokeDasharray="4 4"
                    />
                    <text 
                      x={runPadding - 4} 
                      y={y + 3} 
                      className="fill-stone-300 font-mono text-[9px]" 
                      textAnchor="end"
                    >
                      {valueVal.toFixed(1)}k
                    </text>
                  </g>
                );
              })}

              {/* Area Under Line with entry fade animation */}
              <motion.polygon 
                points={areaPointsString} 
                className="fill-[#e0f2fe]/40"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 0.5 }}
              />

              {/* Animated drawing Running Trend line path */}
              <motion.polyline 
                fill="none" 
                className="stroke-sky-450" 
                strokeWidth={2.5} 
                strokeLinecap="round"
                strokeLinejoin="round"
                points={runPointsString}
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.2, ease: 'easeInOut' }}
              />

              {/* Active Nodes dots & text details */}
              {runPoints.map((pt, i) => (
                <g key={i} className="group/dot">
                  <motion.circle 
                    cx={pt.x} 
                    cy={pt.y} 
                    r={pt.data.distanceKm > 0 ? 4.5 : 2.5} 
                    className={`${pt.data.distanceKm > 0 ? 'fill-sky-400 stroke-white' : 'fill-stone-200 stroke-transparent'}`}
                    strokeWidth={1.5}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: i * 0.08 + 0.3 }}
                  />
                  {pt.data.distanceKm > 0 && (
                    <text 
                      x={pt.x} 
                      y={pt.y - 10} 
                      className="fill-sky-700 font-mono text-[9px] font-bold" 
                      textAnchor="middle"
                    >
                      {pt.data.distanceKm.toFixed(1)}k
                    </text>
                  )}
                  {/* Day labels top alignment */}
                  <text 
                    x={pt.x} 
                    y={runChartHeight - runPadding + 14} 
                    className="fill-stone-400 font-mono text-[10px]" 
                    textAnchor="middle"
                  >
                    {pt.data.label}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          <div className="bg-sky-50/20 p-3 rounded-2xl border border-sky-100/50 flex justify-between items-center mt-3">
            <p className="text-xs text-sky-800">
              Total weekly run distance is <strong className="font-semibold">{runDataMap.reduce((sum, r) => sum + r.distanceKm, 0).toFixed(1)} km</strong>. Nice stamina!
            </p>
          </div>
        </div>

        {/* GYM SETS COMPLETED VERTICAL BAR SVG CHART WITH FADE IN BARS */}
        <div className="bg-white border border-stone-100 p-6 rounded-3xl shadow-sm space-y-4" id="gym-chart-wrapper">
          <div className="flex justify-between items-center">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-purple-500 font-bold bg-[#faf5ff] px-2.5 py-0.5 rounded-full">Volume Load</span>
              <h4 className="text-base font-semibold text-stone-800 tracking-tight mt-1.5">Gym Sets Executed Trend</h4>
            </div>
            <span className="text-xs font-mono text-stone-405">Max: {maxGymSets} sets</span>
          </div>

          <div className="relative">
            <svg 
              viewBox={`0 0 ${gymChartWidth} ${gymChartHeight}`} 
              className="w-full h-auto overflow-visible select-none"
            >
              {/* Grid Background lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
                const y = gymPadding + ratio * (gymChartHeight - gymPadding * 2);
                const valueVal = Math.round(maxGymSets - ratio * maxGymSets);
                return (
                  <g key={i}>
                    <line 
                      x1={gymPadding} 
                      y1={y} 
                      x2={gymChartWidth - gymPadding} 
                      y2={y} 
                      className="stroke-stone-100" 
                      strokeWidth={1} 
                      strokeDasharray="4 4"
                    />
                    <text 
                      x={gymPadding - 4} 
                      y={y + 3} 
                      className="fill-stone-300 font-mono text-[9px]" 
                      textAnchor="end"
                    >
                      {valueVal}S
                    </text>
                  </g>
                );
              })}

              {/* Draw animated bars */}
              {gymDataMap.map((data, idx) => {
                const x = gymPadding + (idx * (gymChartWidth - gymPadding * 2)) / (gymDataMap.length - 1) - barWidth / 2;
                const barHeight = (data.setsCompleted / maxGymSets) * (gymChartHeight - gymPadding * 2);
                const y = gymChartHeight - gymPadding - barHeight;

                return (
                  <g key={idx} className="group/bar">
                    {/* Background hover bar area */}
                    <rect 
                      x={x - 4}
                      y={gymPadding}
                      width={barWidth + 8}
                      height={gymChartHeight - gymPadding * 2}
                      className="fill-stone-50/0 hover:fill-stone-50/20 transition-colors"
                      rx={6}
                    />

                    {/* Core bar animated from the bottom up */}
                    <motion.rect 
                      x={x} 
                      y={y} 
                      width={barWidth} 
                      height={Math.max(barHeight, 2)} 
                      className={`${data.setsCompleted > 0 ? 'fill-purple-300' : 'fill-stone-100'}`}
                      rx={4}
                      initial={{ scaleY: 0, originY: '136px' }}
                      animate={{ scaleY: 1 }}
                      transition={{ duration: 0.8, delay: idx * 0.05, ease: 'easeOut' }}
                    />

                    {/* Highlight metrics labels on bars */}
                    {data.setsCompleted > 0 && (
                      <text 
                        x={x + barWidth / 2} 
                        y={y - 6} 
                        className="fill-purple-700 font-mono text-[9px] font-bold" 
                        textAnchor="middle"
                      >
                        {data.setsCompleted}
                      </text>
                    )}

                    {/* Day labels */}
                    <text 
                      x={x + barWidth / 2} 
                      y={gymChartHeight - gymPadding + 14} 
                      className="fill-stone-400 font-mono text-[10px]" 
                      textAnchor="middle"
                    >
                      {data.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="bg-purple-50/20 p-3 rounded-2xl border border-purple-100/50 flex justify-between items-center mt-3">
            <p className="text-xs text-purple-800">
              Your weekly target output shows <strong className="font-semibold">{gymDataMap.reduce((sum, g) => sum + g.setsCompleted, 0)} sets</strong>. Your training load is solid!
            </p>
          </div>
        </div>

      </div>

      {/* 30 DAYS WEIGHT TRACKING INTERACTIVE CHART COMPONENT */}
      <div className="bg-white border border-stone-100 p-6 rounded-3xl shadow-sm" id="weight-history-section">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Weight SVG graphic area - span 8/12 on large desktops */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-rose-500 font-bold bg-rose-50 px-2.5 py-0.5 rounded-full flex items-center gap-1 w-fit">
                  <Scale className="w-3 h-3" /> Mass Variations Timeline
                </span>
                <h4 className="text-base font-semibold text-stone-850 tracking-tight mt-1.5">Weight Tracking Historical Trail (Past 30 Days)</h4>
              </div>
              
              <div className="text-right">
                <p className="text-xs font-mono text-stone-400">Total Variance</p>
                <div className="flex items-center gap-1 justify-end mt-0.5">
                  {weightDiff === 0 ? (
                    <span className="text-xs font-mono text-stone-500">Unchanged (0.0kg)</span>
                  ) : weightDiff < 0 ? (
                    <span className="text-xs font-mono text-emerald-500 font-semibold flex items-center">
                      <TrendingDown className="w-3.5 h-3.5 mr-0.5" /> Leaned: {weightDiff.toFixed(1)}kg
                    </span>
                  ) : (
                    <span className="text-xs font-mono text-purple-550 font-semibold flex items-center">
                      <TrendingUp className="w-3.5 h-3.5 mr-0.5" /> Gained: +{weightDiff.toFixed(1)}kg
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="relative overflow-x-auto">
              <svg 
                viewBox={`0 0 ${weightChartWidth} ${weightChartHeight}`} 
                className="w-full min-w-[500px] h-auto overflow-visible select-none"
              >
                {/* Horizontal reference grid lines */}
                {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
                  const y = weightPadding + ratio * (weightChartHeight - weightPadding * 2);
                  const val = maxWt - ratio * wtRange;
                  return (
                    <g key={i}>
                      <line 
                        x1={weightPadding} 
                        y1={y} 
                        x2={weightChartWidth - weightPadding} 
                        y2={y} 
                        className="stroke-stone-100" 
                        strokeWidth={1} 
                        strokeDasharray="4 4"
                      />
                      <text 
                        x={weightPadding - 5} 
                        y={y + 3} 
                        className="fill-stone-300 font-mono text-[9px]" 
                        textAnchor="end"
                      >
                        {val.toFixed(1)}k
                      </text>
                    </g>
                  );
                })}

                {/* Soft gradient fill under weight curve line */}
                <motion.polygon 
                  points={weightAreaPointsString} 
                  className="fill-rose-100/20"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 1.2, delay: 0.3 }}
                />

                {/* Draw main weight trend spline line */}
                <motion.polyline 
                  fill="none" 
                  className="stroke-rose-400" 
                  strokeWidth={2.2} 
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={weightPointsString}
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1.5, ease: 'easeInOut' }}
                />

                {/* Nodes rendering for points. Display labels for peak nodes or simple hover nodes */}
                {weightPoints.map((pt, idx) => {
                  // Only display date label for every 5th item to keep the axis simple
                  const showDayLabel = idx % 5 === 0 || idx === weightPoints.length - 1;
                  const isSpecificWeightLogPoint = metrics.some(m => m.date === pt.data.date && m.weightKg !== undefined);

                  return (
                    <g key={idx} className="group/wt-dot">
                      <circle 
                        cx={pt.x} 
                        cy={pt.y} 
                        r={isSpecificWeightLogPoint ? 4.5 : 2} 
                        className={`${isSpecificWeightLogPoint ? 'fill-rose-400 stroke-white cursor-pointer' : 'fill-rose-300 stroke-transparent'}`}
                        strokeWidth={1.5}
                      />
                      
                      {/* Interactive Tooltip showing logged weight */}
                      <g className="opacity-0 group-hover/wt-dot:opacity-100 transition-opacity duration-200 pointer-events-none">
                        <rect 
                          x={pt.x - 30} 
                          y={pt.y - 30} 
                          width={60} 
                          height={20} 
                          rx={4} 
                          className="fill-stone-900 shadow-md"
                        />
                        <text 
                          x={pt.x} 
                          y={pt.y - 17} 
                          className="fill-white font-mono text-[9px] font-bold" 
                          textAnchor="middle"
                        >
                          {pt.data.weightKg.toFixed(1)}kg
                        </text>
                        <text
                          x={pt.x}
                          y={pt.y - 35}
                          className="fill-stone-400 font-mono text-[8px]"
                          textAnchor="middle"
                        >
                          {pt.data.label}
                        </text>
                      </g>

                      {showDayLabel && (
                        <text 
                          x={pt.x} 
                          y={weightChartHeight - weightPadding + 14} 
                          className="fill-stone-400 font-mono text-[9px]" 
                          textAnchor="middle"
                        >
                          {pt.data.label}
                        </text>
                      )}
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>

          {/* Record today's weight side form - span 4/12 */}
          <div className="lg:col-span-4 bg-rose-50/15 rounded-2xl p-5 border border-rose-200/20 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 bg-rose-50 text-rose-550 rounded-xl">
                  <Scale className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-stone-850">Log Daily Body Mass</h4>
                  <p className="text-[11px] text-stone-450">Maintain consistent weight logging to map precise caloric calorie deficits</p>
                </div>
              </div>

              {/* Status Banner */}
              {weightFormStatus === 'saved' && (
                <div className="p-2.5 bg-emerald-50 text-emerald-800 text-[11px] rounded-xl border border-emerald-100 font-medium flex items-center gap-1.5 mb-3">
                  <Check className="w-3.5 h-3.5" />
                  Today's mass log successfully computed!
                </div>
              )}

              <form onSubmit={handleLogWeightToday} className="space-y-3 mt-4">
                <div>
                  <label className="block text-[11px] font-medium text-stone-500 mb-1">Enter Today's Weight (kg)</label>
                  <div className="relative">
                    <input 
                      type="number" 
                      step="0.05"
                      min="35"
                      max="200"
                      placeholder={`Current: ${latestWeight.toFixed(1)}`}
                      value={weightInput}
                      onChange={e => setWeightInput(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-stone-200 focus:outline-none focus:ring-1 focus:ring-rose-300 rounded-xl text-xs shadow-xs font-mono"
                      required
                    />
                    <span className="absolute right-3.5 top-2.5 text-xs text-stone-400 font-semibold">kg</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-rose-500 hover:bg-rose-600 text-white font-semibold rounded-xl text-xs transition shadow-sm cursor-pointer"
                >
                  Record Standard Log
                </button>
              </form>
            </div>

            <div className="pt-4 border-t border-rose-100/40 mt-4 text-[11px] text-stone-400 font-sans italic">
              *Protip: For accurate statistics, measure your body weight immediately upon rising prior to active cardio run.
            </div>
          </div>

        </div>
      </div>

      {/* Aesthetic Milestone Badges section */}
      <div className="bg-white border border-stone-100 rounded-3xl p-6 shadow-sm">
        <h4 className="text-sm font-semibold text-stone-800 mb-4 font-display flex items-center gap-1.5">
          <Award className="w-5 h-5 text-amber-400 animate-pulse" /> Performance Analytics Milestones
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          <div className="p-4 bg-[#f0fdf4]/40 border border-green-100 rounded-2xl flex items-start gap-3">
            <div className="text-emerald-500 mt-0.5 animate-bounce">
              <Check className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-stone-700">Consistency Lock</p>
              <p className="text-[10px] text-stone-500 mt-1">Logged active workouts at least 4 out of the past 7 days successfully.</p>
            </div>
          </div>

          <div className="p-4 bg-[#f0f9ff]/45 border border-sky-100 rounded-2xl flex items-start gap-3">
            <div className="text-sky-500 mt-0.5">
              <Check className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-stone-700">Tempo Marathoner</p>
              <p className="text-[10px] text-stone-500 mt-1">Recorded running intervals with pace counts under 06:15 min/km.</p>
            </div>
          </div>

          <div className="p-4 bg-[#faf5ff]/40 border border-purple-100 rounded-2xl flex items-start gap-3">
            <div className="text-purple-500 mt-0.5">
              <Check className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-stone-700">Aesthetic Diet Balance</p>
              <p className="text-[10px] text-stone-500 mt-1">Maintained positive protein goals exceeding 80 grams cumulative record.</p>
            </div>
          </div>

        </div>
      </div>

      {/* PRINT-READY FULL PERFORMANCE REPORT DOCUMENT PREVIEW MODAL */}
      {showPrintPreview && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 md:p-10 max-w-3xl w-full border border-stone-200 shadow-2xl flex flex-col max-h-[90vh] print:p-0 print:border-none print:shadow-none print:max-h-none">
            
            {/* Modal Tool Controls Header */}
            <div className="flex justify-between items-center mb-6 pb-4 border-b border-stone-100 print:hidden">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-600" />
                <h3 className="text-base font-bold text-stone-850">Aura Active Performance Report (PDF Preview)</h3>
              </div>
              
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" /> Direct Print PDF
                </button>
                <button 
                  onClick={() => setShowPrintPreview(false)}
                  className="p-1.5 hover:bg-stone-50 rounded-xl text-stone-400 hover:text-stone-700 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Print Body Container */}
            <div className="flex-1 overflow-y-auto pr-1 print:overflow-visible" id="aura-performance-printout">
              <div className="space-y-6 text-stone-800 p-2 md:p-6 border border-stone-100 rounded-2xl print:border-none print:p-0">
                {/* Brand Header */}
                <div className="flex justify-between items-start pb-6 border-b-2 border-dashed border-stone-200">
                  <div>
                    <span className="text-xs font-mono font-bold uppercase tracking-widest text-purple-600">AURA ACTIVE TELEMETRY</span>
                    <h1 className="text-2xl font-light tracking-tight text-stone-900 mt-1 font-sans">Athletic & Nutrition Report</h1>
                    <p className="text-[11px] text-stone-400 mt-1">Generated dynamically on {new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-light tracking-wide text-stone-700 font-display">Aura Active Applet</span>
                    <p className="text-[10px] text-stone-400 mt-1 font-mono">ID: aac42df6-bb40</p>
                  </div>
                </div>

                {/* Grid Overview Key Statistics */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-450 font-mono mb-3">I. Performance Indicators Summary</h4>
                  <div className="grid grid-cols-3 gap-4 p-4 bg-stone-50 rounded-2xl">
                    <div>
                      <span className="text-[10px] text-stone-400 uppercase tracking-widest block font-serif">Run Mileage</span>
                      <strong className="text-base text-stone-800 font-mono block mt-0.5">{totalRunningMileage.toFixed(1)} km</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-400 uppercase tracking-widest block font-serif">Workouts Done</span>
                      <strong className="text-base text-stone-800 font-mono block mt-0.5">{workouts.length} completed</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-400 uppercase tracking-widest block font-serif">Gym Sessions</span>
                      <strong className="text-base text-stone-800 font-mono block mt-0.5">{totalGymWorkoutsCount} sessions</strong>
                    </div>
                  </div>
                </div>

                {/* Day-By-Day Telemetry Grid */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-450 font-mono mb-3">II. Past 7-Day Metric Streams</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-stone-600">
                      <thead>
                        <tr className="border-b border-stone-200/60 bg-stone-50/50 text-stone-450 font-mono text-[9px] uppercase tracking-wider">
                          <th className="py-2.5 px-2">Date</th>
                          <th className="py-2.5 px-2">Weight</th>
                          <th className="py-2.5 px-2">Sleep</th>
                          <th className="py-2.5 px-2">Water</th>
                          <th className="py-2.5 px-2">Workout Actions Done</th>
                          <th className="py-2.5 px-2">Active Mins</th>
                        </tr>
                      </thead>
                      <tbody>
                        {last7Days.map(date => {
                          const met = (metrics.find(m => m.date === date) || { date, waterIntakeMl: 0, activeMinutes: 0 }) as DailyMetrics;
                          const dayWorks = workouts.filter(w => w.date === date && w.isCompleted);
                          const dayWorksStr = dayWorks.map(w => w.type === 'gym' ? '💪 Gym day' : `🏃 Run (${(w as any).distanceKm}k)`).join(', ') || 'Rest';
                          return (
                            <tr key={date} className="border-b border-stone-100 hover:bg-stone-50/50">
                              <td className="py-2.5 px-2 font-mono font-bold text-stone-800">{date}</td>
                              <td className="py-2.5 px-2">{met.weightKg ? `${met.weightKg} kg` : 'N/A'}</td>
                              <td className="py-2.5 px-2">{met.sleepHours ? `${met.sleepHours} hrs` : 'N/A'}</td>
                              <td className="py-2.5 px-2 font-mono">{met.waterIntakeMl} ml</td>
                              <td className="py-2.5 px-2">{dayWorksStr}</td>
                              <td className="py-2.5 px-2 font-mono">{met.activeMinutes}m</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Nutrition targets audit */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-450 font-mono mb-3">III. Nutrition & Goal Calibration</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 border border-stone-150 rounded-xl">
                      <span className="text-[10px] uppercase text-stone-400 font-mono font-bold block">Hydration Target Verification</span>
                      <p className="text-xs text-stone-700 mt-1">Daily water log target remains sets at <strong className="font-semibold">{goals.dailyWaterMl} ml</strong>. Active consistency tracking records show optimal tissue saturation ratios.</p>
                    </div>
                    <div className="p-4 border border-stone-150 rounded-xl">
                      <span className="text-[10px] uppercase text-stone-400 font-mono font-bold block">Physical Energy Balance Target</span>
                      <p className="text-xs text-stone-700 mt-1">Required Active Calories expenditure: <strong className="font-semibold">{goals.dailyCaloriesBurned} kcal</strong>. Target nutrient planning budget: <strong className="font-semibold">{goals.dailyCalorieIntake} kcal</strong>.</p>
                    </div>
                  </div>
                </div>

                {/* Bottom citation and disclaimer */}
                <div className="pt-6 border-t border-stone-200 text-center text-[10px] text-stone-400">
                  <p>Aura Active Core Engine &copy; 2026. Data parsed dynamically from verified local sandbox secure datastores.</p>
                </div>

              </div>
            </div>

            {/* Printable Footnote for the preview screen helper */}
            <div className="pt-4 border-t border-stone-105 mt-6 flex justify-end gap-2 print:hidden">
              <button
                onClick={() => setShowPrintPreview(false)}
                className="px-4 py-2 hover:bg-stone-50 border border-stone-200/80 rounded-xl text-stone-500 text-xs font-semibold cursor-pointer"
              >
                Close Preview
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1"
              >
                <Printer className="w-4 h-4" /> Print Document (PDF)
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
