/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Droplet, 
  Flame, 
  Activity, 
  Utensils, 
  Target, 
  Plus, 
  Minus, 
  Settings, 
  Check, 
  X,
  TrendingUp,
  Award,
  Smartphone,
  Sparkles,
  Bell,
  Clock,
  Trash2
} from 'lucide-react';
import { DailyMetrics, UserGoals, Workout, Meal } from '../types';
import { motion } from 'motion/react';
import RunnerMap, { PRESET_TRAILS } from './RunnerMap';
import SpotifyIntegrationPanel from './SpotifyIntegrationPanel';
import { ErrorBoundary } from './ErrorBoundary';


export interface WorkoutReminder {
  id: string;
  time: string; // "18:00"
  workoutType: 'gym' | 'running';
  label: string;
  enabled: boolean;
  days: string[]; // ['Mon', 'Tue', ...]
}

interface DashboardOverviewProps {
  metrics: DailyMetrics[];
  workouts: Workout[];
  meals: Meal[];
  goals: UserGoals;
  onUpdateWater: (amountMl: number) => void;
  onUpdateGoals: (newGoals: UserGoals) => void;
  onAddWorkout: (workout: Omit<Workout, 'id'>) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  themeColorway?: string;
}

export default function DashboardOverview({
  metrics,
  workouts,
  meals,
  goals,
  onUpdateWater,
  onUpdateGoals,
  onAddWorkout,
  setActiveTab,
  themeColorway = 'blossom',
}: DashboardOverviewProps) {
  const [isEditingGoals, setIsEditingGoals] = useState(false);
  const [editedGoals, setEditedGoals] = useState<UserGoals>({ ...goals });
  const [waterInput, setWaterInput] = useState('250');

  // Daily Workout Reminders States
  const [reminders, setReminders] = useState<WorkoutReminder[]>(() => {
    const saved = localStorage.getItem('flow_reminders');
    if (saved) return JSON.parse(saved);
    return [
      { id: 'rem-1', time: '08:00', workoutType: 'running', label: 'Morning Cardio Run', enabled: true, days: ['Tue', 'Thu', 'Sat'] },
      { id: 'rem-2', time: '18:00', workoutType: 'gym', label: 'Evening Gym Power Session', enabled: true, days: ['Mon', 'Wed', 'Fri'] }
    ];
  });

  const [dismissedReminders, setDismissedReminders] = useState<string[]>([]);
  const [approachingReminders, setApproachingReminders] = useState<WorkoutReminder[]>([]);

  // Local Add Reminder Form states
  const [newRemLabel, setNewRemLabel] = useState('');
  const [newRemTime, setNewRemTime] = useState('18:00');
  const [newRemType, setNewRemType] = useState<'gym' | 'running'>('gym');
  const [newRemDays, setNewRemDays] = useState<string[]>(['Mon', 'Wed', 'Fri']);

  useEffect(() => {
    localStorage.setItem('flow_reminders', JSON.stringify(reminders));
  }, [reminders]);

  // Real-time reminders monitor
  useEffect(() => {
    const checkReminders = () => {
      const now = new Date();
      const daysShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const todayShort = daysShort[now.getDay()];
      const currentH = now.getHours();
      const currentM = now.getMinutes();
      const currentTotalMins = currentH * 60 + currentM;

      const approachingList = reminders.filter(rem => {
        if (!rem.enabled || dismissedReminders.includes(rem.id)) return false;
        if (!rem.days.includes(todayShort)) return false;

        const [remH, remM] = rem.time.split(':').map(Number);
        const remTotalMins = remH * 60 + remM;

        // Approaching condition: within 60 minutes before scheduled time, or up to 10 minutes after scheduled time
        const diff = remTotalMins - currentTotalMins;
        return diff >= -10 && diff <= 60;
      });

      setApproachingReminders(approachingList);
    };

    checkReminders();
    const interval = setInterval(checkReminders, 20000);
    return () => clearInterval(interval);
  }, [reminders, dismissedReminders]);

  const handleToggleReminder = (id: string) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r));
  };

  const handleDeleteReminder = (id: string) => {
    setReminders(prev => prev.filter(r => r.id !== id));
  };

  const handleAddReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRemLabel.trim()) return;
    
    const item: WorkoutReminder = {
      id: `rem-gen-${Date.now()}`,
      time: newRemTime || '18:00',
      workoutType: newRemType,
      label: newRemLabel.trim(),
      enabled: true,
      days: newRemDays.length ? newRemDays : ['Mon', 'Wed', 'Fri']
    };

    setReminders(prev => [...prev, item]);
    setNewRemLabel('');
  };

  const handleToggleDay = (day: string) => {
    setNewRemDays(prev => 
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  // Interactive Virtual Cardio Runners Simulator States
  const [selectedTrailIdx, setSelectedTrailIdx] = useState(0);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simDistance, setSimDistance] = useState(0);
  const [simTime, setSimTime] = useState(0);
  const [simBpm, setSimBpm] = useState(72);
  const [simIntensity, setSimIntensity] = useState<'jog' | 'steady' | 'sprint'>('steady');
  const [simPathIdx, setSimPathIdx] = useState(0);

  // Cardio Simulation Clock Loop
  useEffect(() => {
    let timer: any = null;
    if (isSimulating) {
      timer = setInterval(() => {
        setSimTime(t => t + 1);
        setSimDistance(d => d + (simIntensity === 'jog' ? 0.0031 : simIntensity === 'steady' ? 0.0053 : 0.0084));
        setSimBpm(bpm => {
          const targetBpm = simIntensity === 'jog' ? 122 : simIntensity === 'steady' ? 144 : 171;
          const diff = targetBpm - bpm;
          return bpm + Math.round(diff * 0.12) + (Math.random() > 0.45 ? 1 : -1);
        });
        setSimPathIdx(idx => (idx + 1) % 100);
      }, 1000);
    } else {
      setSimTime(0);
      setSimDistance(0);
      setSimBpm(72);
      setSimPathIdx(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isSimulating, simIntensity]);

  // Track parametric math positions for the glowing simulator dot
  const getRunnerCoords = (idx: number) => {
    if (idx < 25) {
      // Top straight leg: from (50, 20) to (150, 20)
      const ratio = idx / 25;
      return { x: 50 + ratio * 100, y: 20 };
    } else if (idx < 50) {
      // Right curved turn around (150, 50) with radius 30
      const ratio = (idx - 25) / 25;
      const angle = -Math.PI / 2 + ratio * Math.PI;
      return { x: 150 + Math.cos(angle) * 30, y: 50 + Math.sin(angle) * 30 };
    } else if (idx < 75) {
      // Bottom straight leg: from (150, 80) to (50, 80)
      const ratio = (idx - 50) / 25;
      return { x: 150 - ratio * 100, y: 80 };
    } else {
      // Left curved turn around (50, 50) with radius 30
      const ratio = (idx - 75) / 25;
      const angle = Math.PI / 2 + ratio * Math.PI;
      return { x: 50 + Math.cos(angle) * 30, y: 50 + Math.sin(angle) * 30 };
    }
  };

  const runnerPos = getRunnerCoords(simPathIdx);

  const handleSaveSimulatedWorkout = () => {
    const activeTrail = PRESET_TRAILS[selectedTrailIdx] || PRESET_TRAILS[0];
    onAddWorkout({
      type: 'running',
      durationMinutes: Math.ceil(simTime / 60) || 1,
      date: new Date().toISOString().split('T')[0],
      caloriesBurned: Math.round(simDistance * 62),
      isCompleted: true,
      distanceKm: parseFloat(simDistance.toFixed(2)),
      pacePerKm: simIntensity === 'jog' ? '06:15' : simIntensity === 'steady' ? '05:15' : '04:05',
      routeType: 'outdoor',
      notes: `Simulated run on the ${activeTrail.name} in ${activeTrail.city}. Average pace: ${simIntensity === 'jog' ? '6:15/km' : simIntensity === 'steady' ? '5:15/km' : '4:05/km'}.`
    } as any);
    setIsSimulating(false);
  };

  // Active metrics (today's entry)
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayMetrics = metrics.find(m => m.date === todayDateStr) || {
    date: todayDateStr,
    waterIntakeMl: 1200,
    waterGoalMl: goals.dailyWaterMl,
    activeMinutes: 30,
    sleepHours: 7.0,
  };

  // Calculations for current week
  const startOfWeek = new Date();
  startOfWeek.setDate(startOfWeek.getDate() - 7);
  
  const weeklyWorkouts = workouts.filter(w => new Date(w.date) >= startOfWeek && w.isCompleted);
  const gymWorkoutsCount = weeklyWorkouts.filter(w => w.type === 'gym').length;
  const runningDistance = weeklyWorkouts
    .filter(w => w.type === 'running')
    // @ts-ignore
    .reduce((sum, w) => sum + (w.distanceKm || 0), 0);

  const caloriesBurnedToday = workouts
    .filter(w => w.date === todayDateStr && w.isCompleted)
    .reduce((sum, w) => sum + w.caloriesBurned, 0);

  // Percentages with cap at 100
  const waterPct = Math.min(100, Math.round((todayMetrics.waterIntakeMl / goals.dailyWaterMl) * 100));
  const activeMinsPct = Math.min(100, Math.round((todayMetrics.activeMinutes / 60) * 100)); // default 60min goal
  const gymGoalPct = Math.min(100, Math.round((gymWorkoutsCount / goals.weeklyGymWorkouts) * 100));
  const runGoalPct = Math.min(100, Math.round((runningDistance / goals.weeklyRunningDistanceKm) * 100));

  const handleSaveGoals = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateGoals(editedGoals);
    setIsEditingGoals(false);
  };

  // Pastel SVG progress rings helper
  const ProgressRing = ({ 
    percent, 
    strokeWidth = 6, 
    colorClass = "stroke-teal-200", 
    trailColorClass = "stroke-stone-100",
    size = 72,
    children
  }: { 
    percent: number; 
    strokeWidth?: number; 
    colorClass?: string; 
    trailColorClass?: string;
    size?: number;
    children?: React.ReactNode;
  }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const strokeDashoffset = circumference - (percent / 100) * circumference;

    return (
      <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
        <svg className="transform -rotate-90" width={size} height={size}>
          {/* Background circle */}
          <circle
            className={`${trailColorClass} fill-transparent`}
            strokeWidth={strokeWidth}
            r={radius}
            cx={size / 2}
            cy={size / 2}
          />
          {/* Foreground progress circle */}
          <motion.circle
            className={`${colorClass} fill-transparent`}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: strokeDashoffset }}
            transition={{ duration: 1, ease: 'easeOut' }}
            strokeLinecap="round"
            r={radius}
            cx={size / 2}
            cy={size / 2}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          {children}
        </div>
      </div>
    );
  };

  const currentHour = new Date().getHours();
  let greeting = 'Fulfill your potential';
  if (currentHour < 12) greeting = 'A refreshing start';
  else if (currentHour < 18) greeting = 'Stay consistent and strong';
  else greeting = 'Unwind and track your progress';

  return (
    <div className="space-y-8" id="dashboard-container">
      {/* Dynamic Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-100 pb-6">
        <div>
          <span className="text-xs uppercase tracking-widest text-stone-400 font-mono" id="today-timestamp">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
          </span>
          <h1 className="text-4xl font-light tracking-tight text-stone-800 mt-1" id="dashboard-heading">
            Your Flow Dashboard
          </h1>
          <p className="text-stone-400 text-sm mt-1">{greeting}</p>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => {
              setEditedGoals({ ...goals });
              setIsEditingGoals(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-stone-50 hover:bg-stone-100 border border-stone-200/60 rounded-full text-xs font-medium text-stone-600 transition-colors cursor-pointer"
            id="edit-goals-btn"
          >
            <Settings className="w-3.5 h-3.5" />
            Adjust Daily Targets
          </button>
        </div>
      </div>

      {/* Approaching Workout Reminders Notification Stack */}
      {approachingReminders.length > 0 && (
        <div className="space-y-3" id="approaching-reminders-banner">
          {approachingReminders.map(rem => {
            const [h, m] = rem.time.split(':').map(Number);
            const remTotalMins = h * 60 + m;
            const now = new Date();
            const currentTotalMins = now.getHours() * 60 + now.getMinutes();
            const minsLeft = remTotalMins - currentTotalMins;

            return (
              <div 
                key={rem.id} 
                className="bg-gradient-to-r from-purple-50 via-rose-50 to-indigo-50 border border-purple-200/85 p-4 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100/80 text-purple-600 rounded-xl relative">
                    <Bell className="w-5 h-5 animate-bounce" />
                    <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-wider text-purple-600 font-bold block">
                      ⚡ UPCOMING WORKOUT REMINDER
                    </span>
                    <h4 className="text-sm font-semibold text-stone-850 mt-0.5">
                      {rem.label} &mdash; <span className="text-purple-600 font-semibold">{rem.workoutType === 'gym' ? '💪 Strength Training Session' : '🏃 Cardio Running Circuit'}</span>
                    </h4>
                    <p className="text-[11px] text-stone-500 mt-0.5">
                      Scheduled today at <strong className="font-semibold text-stone-700 font-mono">{rem.time}</strong>
                      {minsLeft > 0 ? ` (in ${minsLeft} minutes)` : minsLeft === 0 ? ` (happening right now!)` : ` (started ${Math.abs(minsLeft)} mins ago)`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto self-stretch sm:self-auto">
                  <button 
                    onClick={() => {
                      setActiveTab('workouts');
                    }}
                    className="flex-1 sm:flex-none px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold transition cursor-pointer text-center"
                  >
                    Launch Logging Trails
                  </button>
                  <button 
                    onClick={() => setDismissedReminders(prev => [...prev, rem.id])}
                    className="p-1.5 hover:bg-stone-100 rounded-xl text-stone-400 hover:text-stone-700 cursor-pointer"
                    title="Dismiss Notification"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Fitness Targets Configuration Modal */}
      {isEditingGoals && (
        <div className="fixed inset-0 z-50 bg-stone-900/10 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 md:p-8 max-w-md w-full border border-stone-100 shadow-xl transition-all">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-medium text-stone-800">Customize Focus Targets</h3>
              <button 
                onClick={() => setIsEditingGoals(false)}
                className="p-1 rounded-full hover:bg-stone-50 text-stone-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveGoals} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-stone-500 mb-1">Daily Blue Water Target (ml)</label>
                <input 
                  type="number" 
                  value={editedGoals.dailyWaterMl}
                  onChange={e => setEditedGoals({ ...editedGoals, dailyWaterMl: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full px-3 py-2 bg-stone-50 rounded-lg text-sm border border-stone-200 focus:outline-none focus:ring-1 focus:ring-pink-300"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-500 mb-1">Target Daily Calorie Intake (kcal)</label>
                <input 
                  type="number" 
                  value={editedGoals.dailyCalorieIntake}
                  onChange={e => setEditedGoals({ ...editedGoals, dailyCalorieIntake: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full px-3 py-2 bg-stone-50 rounded-lg text-sm border border-stone-200 focus:outline-none focus:ring-1 focus:ring-pink-300"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-500 mb-1">Target Daily Active Calories (kcal)</label>
                <input 
                  type="number" 
                  value={editedGoals.dailyCaloriesBurned}
                  onChange={e => setEditedGoals({ ...editedGoals, dailyCaloriesBurned: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full px-3 py-2 bg-stone-50 rounded-lg text-sm border border-stone-200 focus:outline-none focus:ring-1 focus:ring-pink-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-stone-500 mb-0.5">Weekly Gym target</label>
                  <input 
                    type="number" 
                    value={editedGoals.weeklyGymWorkouts}
                    onChange={e => setEditedGoals({ ...editedGoals, weeklyGymWorkouts: Math.max(0, parseInt(e.target.value) || 0) })}
                    className="w-full px-3 py-2 bg-stone-50 rounded-lg text-sm border border-stone-200 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-stone-500 mb-0.5">Weekly Running (km)</label>
                  <input 
                    type="number" 
                    value={editedGoals.weeklyRunningDistanceKm}
                    onChange={e => setEditedGoals({ ...editedGoals, weeklyRunningDistanceKm: Math.max(0, parseFloat(e.target.value) || 0) })}
                    className="w-full px-3 py-2 bg-stone-50 rounded-lg text-sm border border-stone-200 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button 
                  type="button" 
                  onClick={() => setIsEditingGoals(false)}
                  className="flex-1 px-4 py-2 border border-stone-200 rounded-xl text-xs font-medium text-stone-500 hover:bg-stone-50"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2 bg-stone-800 text-white rounded-xl text-xs font-medium hover:bg-stone-900 transition-colors"
                >
                  Save Targets
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Main Stats Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="bento-grid-stats">
        
        {/* Core Animated 3D Glass Tracker 1 - Water */}
        <div className="bg-[#f0f9ff]/60 hover:bg-[#f0f9ff]/80 transition-all border border-blue-200/50 p-5 rounded-3xl flex flex-col justify-between" id="stat-card-water">
          <div className="flex justify-between items-start mb-2">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-blue-500 font-bold block mb-0.5">Hydration Unit</span>
              <p className="text-xs text-stone-400 font-medium">Daily Target progress</p>
            </div>
            <span className="text-xs font-mono font-bold text-blue-600 bg-sky-100 hover:bg-sky-200 px-2 py-0.5 rounded-full transition-colors cursor-pointer" onClick={() => onUpdateWater(-todayMetrics.waterIntakeMl)}>
              Reset 🧊
            </span>
          </div>

          {/* Graphical Glass Fill representation */}
          <div className="flex flex-col items-center my-3 relative">
            <div className="relative w-24 h-36 border-4 border-stone-200 rounded-b-2xl bg-white/40 overflow-hidden shadow-inner flex flex-col justify-end">
              
              {/* Liquid content */}
              <motion.div 
                className="w-full bg-linear-to-t from-sky-400 to-sky-300 relative flex items-end overflow-hidden" 
                initial={{ height: 0 }}
                animate={{ height: `${waterPct}%` }}
                transition={{ duration: 1.2, ease: 'easeOut' }}
              >
                {/* Simulated wavy overlay */}
                <div className="absolute top-0 inset-x-0 h-2.5 bg-sky-200/80 animate-pulse" />
                
                {/* Tiny bubbles floating up */}
                <div className="absolute bottom-4 left-3 w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce" />
                <div className="absolute bottom-12 right-4 w-2 h-2 rounded-full bg-white/40 animate-bounce [animation-delay:0.7s]" />
                <div className="absolute bottom-8 left-10 w-1.5 h-1.5 rounded-full bg-white/50 animate-bounce [animation-delay:1.5s]" />
              </motion.div>

              {/* Central absolute percent badge */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none select-none z-10">
                <span className="text-[11px] font-mono font-bold text-sky-800 bg-white/70 backdrop-blur-xs px-2.5 py-1 rounded-full border border-sky-100/80 shadow-xs">
                  {waterPct}%
                </span>
              </div>
            </div>
          </div>

          {/* Value Display */}
          <div className="text-center mb-4">
            <h3 className="text-2xl font-semibold text-stone-800 tracking-tight font-display">{todayMetrics.waterIntakeMl} <span className="text-stone-400 text-xs font-normal">/ {goals.dailyWaterMl} ml</span></h3>
          </div>

          {/* Quick Incremental actions */}
          <div className="grid grid-cols-3 gap-1 border-t border-sky-100/60 pt-3">
            <button 
              onClick={() => onUpdateWater(150)}
              className="py-1.5 bg-white hover:bg-sky-50 text-sky-700 text-[10px] font-semibold rounded-lg border border-sky-100 hover:border-sky-200 transition text-center cursor-pointer"
              title="Add Short Glass Cup"
            >
              🥛 150ml
            </button>
            <button 
              onClick={() => onUpdateWater(250)}
              className="py-1.5 bg-sky-400 hover:bg-sky-500 text-white text-[10px] font-semibold rounded-lg shadow-xs transition text-center cursor-pointer"
              title="Add Standard Water Cup"
            >
              🥤 250ml
            </button>
            <button 
              onClick={() => onUpdateWater(500)}
              className="py-1.5 bg-white hover:bg-sky-50 text-sky-700 text-[10px] font-semibold rounded-lg border border-sky-100 hover:border-sky-200 transition text-center cursor-pointer"
              title="Add Bottle Container"
            >
              🍼 500ml
            </button>
          </div>
        </div>

        {/* Core Ring Tracker 2 - Active Output */}
        <div className="bg-[#f0fdf4]/50 hover:bg-[#f0fdf4]/80 transition-all border border-green-100/60 p-6 rounded-3xl" id="stat-card-active">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2.5 bg-green-100/60 rounded-2xl text-green-600">
              <Activity className="w-5 h-5 stroke-[2]" />
            </div>
            <span className="text-xs font-mono text-green-600 font-medium px-2 py-0.5 bg-emerald-200/25 rounded-full">
              {activeMinsPct}%
            </span>
          </div>

          <div className="flex items-center justify-between gap-2 mt-2">
            <div>
              <p className="text-xs text-stone-400 font-medium uppercase tracking-wider">Exercise Minutes</p>
              <h3 className="text-2xl font-semibold tracking-tight text-stone-800 font-display mt-0.5">
                {todayMetrics.activeMinutes} <span className="text-stone-400 text-sm font-normal">/ 60 min</span>
              </h3>
            </div>
            <ProgressRing percent={activeMinsPct} colorClass="stroke-emerald-400" trailColorClass="stroke-emerald-100/80" size={54} />
          </div>

          <div className="mt-5 border-t border-green-100/30 pt-4">
            <div className="flex justify-between text-xs text-stone-400 font-mono">
              <span>Goal: 60 mins</span>
              <span className="text-green-600 font-medium">Done: {todayMetrics.activeMinutes}m</span>
            </div>
            <div className="w-full bg-stone-100/80 h-1.5 rounded-full mt-2 overflow-hidden">
              <motion.div 
                className="bg-emerald-400 h-full rounded-full" 
                initial={{ width: 0 }}
                animate={{ width: `${activeMinsPct}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
              />
            </div>
          </div>
        </div>

        {/* Core Ring Tracker 3 - Calories Burned */}
        <div className="bg-[#fff1f2]/50 hover:bg-[#fff1f2]/80 transition-all border border-rose-100/60 p-6 rounded-3xl" id="stat-card-energy">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2.5 bg-rose-100/60 rounded-2xl text-rose-500">
              <Flame className="w-5 h-5 stroke-[2]" />
            </div>
            <span className="text-xs font-mono text-rose-500 font-medium px-2 py-0.5 bg-rose-200/20 rounded-full">
              {Math.min(100, Math.round((caloriesBurnedToday / goals.dailyCaloriesBurned) * 100))}%
            </span>
          </div>

          <div className="flex items-center justify-between gap-2 mt-2">
            <div>
              <p className="text-xs text-stone-400 font-medium uppercase tracking-wider">Active Burned</p>
              <h3 className="text-2xl font-semibold tracking-tight text-stone-800 font-display mt-0.5">
                {caloriesBurnedToday} <span className="text-stone-400 text-sm font-normal">/ {goals.dailyCaloriesBurned} kcal</span>
              </h3>
            </div>
            <ProgressRing 
              percent={Math.min(100, Math.round((caloriesBurnedToday / goals.dailyCaloriesBurned) * 100))} 
              colorClass="stroke-rose-400" 
              trailColorClass="stroke-rose-100" 
              size={54} 
            />
          </div>

          <p className="text-[11px] text-stone-400 mt-5 font-mono">
            {caloriesBurnedToday >= goals.dailyCaloriesBurned ? '🎉 Daily active burn objective accomplished!' : 'Log athletic sessions below to heat up!'}
          </p>
        </div>

        {/* Core Ring Tracker 4 - Nutrition Target */}
        <div className="bg-[#faf5ff]/50 hover:bg-[#faf5ff]/80 transition-all border border-purple-100/60 p-6 rounded-3xl" id="stat-card-diet">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2.5 bg-purple-100/60 rounded-2xl text-purple-500">
              <Utensils className="w-5 h-5 stroke-[2]" />
            </div>
            <span className="text-xs font-mono text-purple-500 font-medium px-2 py-0.5 bg-purple-200/20 rounded-full">
              Interactive
            </span>
          </div>

          <div className="flex items-center justify-between gap-2 mt-2">
            <div>
              <p className="text-xs text-stone-400 font-medium uppercase tracking-wider font-sans">Meal Planning</p>
              <h3 className="text-2xl font-semibold tracking-tight text-purple-900 font-display mt-0.5">
                Recipes
              </h3>
            </div>
            <button 
              onClick={() => setActiveTab('meals')}
              className="w-10 h-10 bg-purple-100/60 rounded-full hover:bg-purple-200/60 text-purple-600 flex items-center justify-center transition-colors cursor-pointer"
              title="Add food log"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-6 border-t border-purple-100/40 pt-4 flex justify-between items-center text-xs text-stone-400 font-medium">
            <span>Daily target:</span>
            <span className="text-stone-800 font-mono font-medium">{goals.dailyCalorieIntake} kcal</span>
          </div>
        </div>

      </div>

      {/* 3D Visual Cardio Pace simulator bento component */}
      <div className="bg-gradient-to-tr from-pink-50/75 via-white to-purple-50/80 border border-purple-200/50 p-6 rounded-3xl shadow-xs relative overflow-hidden" id="cardio-live-simulator-block">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-200/20 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 relative z-10">
          <div>
            <span className="text-[10px] uppercase tracking-widest text-purple-600 font-mono font-bold bg-purple-100/60 px-2.5 py-0.5 rounded-full border border-purple-200/50">
              🏃 LIVE STADIUM TRACK RUN
            </span>
            <h2 className="text-2xl font-light tracking-tight text-stone-800 mt-2">
              Virtual Pace & Athletic Track Simulator
            </h2>
            <p className="text-xs text-stone-400 mt-1">
              Start simulations inside a vector-drawn track stadium, control paces dynamically, and sync real-time cardiovascular outcomes to active gains logs!
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!isSimulating ? (
              <button 
                onClick={() => setIsSimulating(true)}
                className="px-5 py-2.5 bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:from-purple-600 hover:to-indigo-600 rounded-xl text-xs font-semibold shadow-md shadow-purple-200 transition-all cursor-pointer flex items-center gap-1.5"
                id="start-cardio-simulator-btn"
              >
                Launch Virtual Simulator
              </button>
            ) : (
              <div className="flex items-center gap-1.5">
                <button 
                  onClick={handleSaveSimulatedWorkout}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold transition cursor-pointer"
                >
                  Save & Complete Log
                </button>
                <button 
                  onClick={() => setIsSimulating(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-500 rounded-xl text-xs font-semibold transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Dynamic simulator graphics viewport */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center relative z-10">
          
          {/* Left Graphic Sandbox Panel: Live Map & Location selector */}
          <div className="md:col-span-6 flex flex-col space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-stone-500 font-mono uppercase tracking-wider block font-bold">Select Active Trail:</span>
              {isSimulating && (
                <span className="text-purple-600 animate-pulse text-[10px] font-mono font-bold flex items-center gap-1.5 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-600 inline-block animate-ping" />
                  LIVE TRAIL TRAVERSE
                </span>
              )}
            </div>

            {/* PRESET TRAILS SELECTION BAR */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-stone-100/80 border border-stone-200/50 rounded-xl">
              {PRESET_TRAILS.map((trailItem, idx) => (
                <button
                  key={trailItem.id}
                  disabled={isSimulating}
                  onClick={() => setSelectedTrailIdx(idx)}
                  className={`py-1.5 px-2 text-[10px] font-semibold rounded-lg text-center transition-all cursor-pointer truncate ${
                    selectedTrailIdx === idx 
                      ? 'bg-white text-purple-700 shadow-sm border border-purple-200/50 font-bold' 
                      : 'text-stone-500 hover:text-stone-850 hover:bg-white/50'
                  } ${isSimulating ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <span className="mr-1">{trailItem.icon}</span>
                  {trailItem.name.split(' ')[0]}
                </button>
              ))}
            </div>

            {/* THE ACTUAL GOOGLE MAP */}
            <ErrorBoundary>
              <RunnerMap 
                selectedTrailIdx={selectedTrailIdx}
                simPathIdx={simPathIdx}
                isSimulating={isSimulating}
                themeColorway={themeColorway}
              />
            </ErrorBoundary>
          </div>

          {/* Right Metrics summary: Real time changing counts */}
          <div className="md:col-span-6 space-y-4">
            <div className="grid grid-cols-3 gap-3">
              
              {/* Metric Card: Distance */}
              <div className="bg-white/95 p-3 rounded-xl border border-stone-150 text-center shadow-xs">
                <span className="text-[9px] font-mono uppercase tracking-wider text-stone-400 block">Distance Done</span>
                <span className="text-xl font-bold font-mono text-purple-700 block mt-0.5">
                  {simDistance.toFixed(2)} <span className="text-[10px] font-normal text-stone-400">km</span>
                </span>
                <span className="text-[9px] font-mono text-emerald-500 block">+{simIntensity === 'jog' ? '3m' : simIntensity === 'steady' ? '5m' : '8m'}/s</span>
              </div>

              {/* Metric Card: Real-time Timer */}
              <div className="bg-white/95 p-3 rounded-xl border border-stone-150 text-center shadow-xs">
                <span className="text-[9px] font-mono uppercase tracking-wider text-stone-400 block">Active Time</span>
                <span className="text-xl font-bold font-mono text-stone-850 block mt-0.5">
                  {Math.floor(simTime / 60)}:{String(simTime % 60).padStart(2, '0')}
                </span>
                <span className="text-[9px] font-mono text-stone-400 block">minutes</span>
              </div>

              {/* Metric Card: Cardiovascular Pulsing rate */}
              <div className="bg-white/95 p-3 rounded-xl border border-stone-150 text-center shadow-xs relative overflow-hidden">
                <span className="text-[9px] font-mono uppercase tracking-wider text-stone-400 block">Pulse Rate</span>
                <span className="text-xl font-bold font-mono text-rose-600 block mt-0.5 animate-pulse">
                  {simBpm} <span className="text-[9px] font-normal text-stone-400 font-sans">bpm</span>
                </span>
                <span className="text-[9px] font-mono text-rose-400 block">Stamina high</span>
              </div>

            </div>

            {/* Simulated Pace Selector: change simulator pace */}
            <div className="bg-white/60 p-4 rounded-xl border border-stone-200/40">
              <span className="text-[10px] font-mono uppercase tracking-wider text-stone-500 block mb-2 font-bold">Configure Simulated Run Rate:</span>
              <div className="grid grid-cols-3 gap-1.5">
                <button 
                  onClick={() => setSimIntensity('jog')}
                  className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    simIntensity === 'jog' ? 'bg-amber-100 text-amber-700 font-bold border border-amber-300' : 'bg-stone-50 text-stone-500 hover:bg-stone-100'
                  }`}
                >
                  🏃 Slow Jog
                </button>
                <button 
                  onClick={() => setSimIntensity('steady')}
                  className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    simIntensity === 'steady' ? 'bg-purple-100 text-purple-700 font-bold border border-purple-300' : 'bg-stone-50 text-stone-500 hover:bg-stone-100'
                  }`}
                >
                  ⚡ Steady Pace
                </button>
                <button 
                  onClick={() => setSimIntensity('sprint')}
                  className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    simIntensity === 'sprint' ? 'bg-rose-100 text-rose-700 font-bold border border-rose-300' : 'bg-stone-50 text-stone-500 hover:bg-stone-100'
                  }`}
                >
                  🔥 Sprint Mode
                </button>
              </div>
            </div>

          </div>

        </div>
      </div>

      {/* Visual Weekly Milestones Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        
        {/* Left Column: Weekly Milestones and Quick progress gauges */}
        <div className="md:col-span-7 bg-white border border-stone-100 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-2">
                <div className="p-1 px-2.5 bg-amber-50 border border-amber-200 rounded-full text-amber-500 flex items-center gap-1 font-mono text-xs">
                  <Award className="w-3.5 h-3.5" />
                  Weekly Progress
                </div>
              </div>
              <span className="text-xs font-mono text-stone-400">Past 7 days metrics</span>
            </div>

            <div className="space-y-6">
              {/* Gym Target Gauge */}
              <div id="weekly-gym-progress-gauge">
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-sm text-stone-700 font-medium">Strength Gym Sessions Done</span>
                  <span className="text-xs font-mono font-semibold text-stone-800">
                    {gymWorkoutsCount} <span className="text-stone-300">/</span> {goals.weeklyGymWorkouts} sessions
                  </span>
                </div>
                <div className="w-full bg-stone-100 h-2.5 rounded-full overflow-hidden">
                  <motion.div 
                    className="bg-emerald-300 h-full rounded-full" 
                    initial={{ width: 0 }}
                    animate={{ width: `${gymGoalPct}%` }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                  />
                </div>
                <p className="text-xs text-stone-400 mt-1.5 font-mono">
                  {gymGoalPct >= 100 ? '⭐ Target hit! Excellent dedication.' : `${goals.weeklyGymWorkouts - gymWorkoutsCount} gym days remaining to fulfill target.`}
                </p>
              </div>

              {/* Run Target Gauge */}
              <div id="weekly-run-progress-gauge">
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-sm text-stone-700 font-medium">Running Distances Accumulation</span>
                  <span className="text-xs font-mono font-semibold text-stone-800">
                    {runningDistance.toFixed(1)} <span className="text-stone-300">/</span> {goals.weeklyRunningDistanceKm} km
                  </span>
                </div>
                <div className="w-full bg-stone-100 h-2.5 rounded-full overflow-hidden">
                  <motion.div 
                    className="bg-sky-300 h-full rounded-full" 
                    initial={{ width: 0 }}
                    animate={{ width: `${runGoalPct}%` }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                  />
                </div>
                <p className="text-xs text-stone-400 mt-1.5 font-mono">
                  {runGoalPct >= 100 ? '🚀 Splendid mileage! Target achieved.' : `${(goals.weeklyRunningDistanceKm - runningDistance).toFixed(1)} km left to complete running benchmark.`}
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-stone-100 flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-[#fafaf9] -mx-6 -mb-6 p-6 rounded-b-3xl">
            <div className="flex items-center gap-3">
              <div className="w-7 h-7 bg-amber-100/50 rounded-full flex items-center justify-center text-amber-600">
                <TrendingUp className="w-4 h-4" />
              </div>
              <p className="text-xs text-stone-500 max-w-[200px]">
                Consistency beats intensity. Achieve 3 sequential weeks to trigger a streak.
              </p>
            </div>
            <button 
              onClick={() => setActiveTab('analytics')}
              className="text-xs bg-white text-stone-700 font-medium tracking-tight hover:bg-stone-50 border border-stone-200 px-4 py-2 rounded-xl transition-all cursor-pointer"
              id="view-analytics-shortcut"
            >
              Examine Analytics
            </button>
          </div>
        </div>

        {/* Right Column: Mini Checklist or aesthetic quote */}
        <div className="md:col-span-5 bg-stone-55 flex flex-col gap-6">
          <div className="bg-white border border-stone-100 rounded-3xl p-6 shadow-sm flex-1 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-medium text-stone-800 mb-4 uppercase tracking-wider flex items-center gap-2">
                <Target className="w-4 h-4 text-purple-400" /> Current Focus Checklist
              </h3>
              
              <div className="space-y-3.5">
                <div className="flex items-start gap-3">
                  <div className={`p-0.5 rounded-full mt-0.5 ${waterPct >= 100 ? 'bg-emerald-100 text-emerald-600' : 'bg-stone-100 text-stone-400'}`}>
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className={`text-xs font-medium ${waterPct >= 100 ? 'text-stone-400 line-through' : 'text-stone-700'}`}>Achieve Hydration Goal</p>
                    <span className="text-[10px] text-stone-400 font-mono">Today: {todayMetrics.waterIntakeMl}ml / {goals.dailyWaterMl}ml</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className={`p-0.5 rounded-full mt-0.5 ${activeMinsPct >= 100 ? 'bg-emerald-100 text-emerald-600' : 'bg-stone-100 text-stone-400'}`}>
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className={`text-xs font-medium ${activeMinsPct >= 100 ? 'text-stone-400 line-through' : 'text-stone-700'}`}>Perform 60 mins activity</p>
                    <span className="text-[10px] text-stone-400 font-mono">Today: {todayMetrics.activeMinutes} mins logged</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className={`p-0.5 rounded-full mt-0.5 ${caloriesBurnedToday >= goals.dailyCaloriesBurned ? 'bg-emerald-100 text-emerald-600' : 'bg-stone-100 text-stone-400'}`}>
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className={`text-xs font-medium ${caloriesBurnedToday >= goals.dailyCaloriesBurned ? 'text-stone-400 line-through' : 'text-stone-700'}`}>Met Daily Athletic Output Target</p>
                    <span className="text-[10px] text-stone-400 font-mono">Today: {caloriesBurnedToday} kcal burned</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-stone-100 mt-6 text-center">
              <span className="text-[11px] font-mono text-stone-400 block italic">"The only workout you regret is the one that did not happen."</span>
            </div>
          </div>

          {/* Unique Live Stats Badge */}
          <div className="bg-[#faf5ff]/70 border border-purple-100/60 rounded-3xl p-6 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-purple-600 block mb-0.5">Gym stats</span>
              <span className="text-xl font-light text-stone-800">Weekly exercises</span>
            </div>
            <div className="text-right">
              <span className="text-2xl font-semibold font-mono text-purple-600 block">
                {workouts.reduce((sum, w) => sum + (w.type === 'gym' ? w.exercises.length : 0), 0)}
              </span>
              <span className="text-[10px] font-mono text-stone-400 block">Completed sets</span>
            </div>
          </div>
        </div>

      </div>

      {/* Workout Reminders Setup Component */}
      <div className="bg-white border border-stone-100 rounded-3xl p-6 shadow-sm mt-8" id="reminders-setup-section">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 pb-4 border-b border-stone-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-purple-50 rounded-xl text-purple-600">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-stone-850">Daily Workout Reminders</h3>
              <p className="text-xs text-stone-400">Schedule automatic alerts to nudge you when custom gym or run sessions approach</p>
            </div>
          </div>
          <span className="text-xs font-mono py-1 px-3 bg-stone-50 border border-stone-200/50 rounded-full text-stone-600">
            {reminders.filter(r => r.enabled).length} Active Notifications
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* List of existing reminders */}
          <div className="lg:col-span-7 space-y-4">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-stone-450 mb-3 font-mono">My Alert Schedules</h4>
            
            {reminders.length === 0 ? (
              <div className="bg-stone-50 border border-dashed border-stone-200/60 p-8 rounded-2xl text-center text-stone-400">
                <Clock className="w-8 h-8 text-stone-300 mx-auto mb-2" />
                <p className="text-sm font-medium">No workout reminders scheduled yet</p>
                <p className="text-xs text-stone-400 mt-1">Configure your target timeline on the right to start receiving alerts.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {reminders.map(rem => (
                  <div key={rem.id} className="p-4 bg-stone-50/50 hover:bg-stone-50 border border-stone-200/40 rounded-2xl flex justify-between items-center gap-4 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="mt-1">
                        <Clock className={`w-4 h-4 ${rem.enabled ? 'text-purple-500' : 'text-stone-300'}`} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-stone-800 font-mono">{rem.time}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                            rem.workoutType === 'gym' ? 'bg-emerald-100 text-emerald-700' : 'bg-sky-100 text-sky-700'
                          }`}>
                            {rem.workoutType === 'gym' ? '🏆 Gym' : '⚡ Run'}
                          </span>
                        </div>
                        <h5 className="text-xs font-medium text-stone-700 mt-1">{rem.label}</h5>
                        <div className="flex flex-wrap gap-1 mt-1.5">
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => {
                            const active = rem.days.includes(day);
                            return (
                              <span 
                                key={day} 
                                className={`text-[9px] font-mono px-1 rounded-sm ${
                                  active ? 'text-purple-600 bg-purple-50 font-semibold' : 'text-stone-300'
                                }`}
                              >
                                {day}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {/* Toggle status switch */}
                      <button
                        onClick={() => handleToggleReminder(rem.id)}
                        className={`w-9 h-5 rounded-full p-0.5 transition-colors cursor-pointer relative ${
                          rem.enabled ? 'bg-purple-600' : 'bg-stone-300'
                        }`}
                        title={rem.enabled ? 'Disable alert' : 'Enable alert'}
                      >
                        <div className={`w-4 h-4 rounded-full bg-white shadow-xs transition-transform transform ${
                          rem.enabled ? 'translate-x-4' : 'translate-x-0'
                        }`} />
                      </button>

                      {/* Delete */}
                      <button
                        onClick={() => handleDeleteReminder(rem.id)}
                        className="p-1.5 hover:bg-stone-100 text-stone-400 hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                        title="Delete Schedule"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Configuration Form to add alerts */}
          <div className="lg:col-span-5 bg-purple-50/10 rounded-2xl p-5 border border-purple-200/20">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-purple-700 mb-3 font-mono flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Add New Alert Nudge
            </h4>

            <form onSubmit={handleAddReminder} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-stone-500 mb-1">Workout label</label>
                <input 
                  type="text"
                  placeholder="e.g. Legs Hypertrophy, Sunset 5k Run..."
                  value={newRemLabel}
                  onChange={e => setNewRemLabel(e.target.value)}
                  className="w-full px-3 py-2 bg-white rounded-xl text-xs border border-stone-200 focus:outline-none focus:ring-1 focus:ring-purple-300 shadow-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-stone-500 mb-1">Alert Time (24h)</label>
                  <input 
                    type="time"
                    value={newRemTime}
                    onChange={e => setNewRemTime(e.target.value)}
                    className="w-full px-3 py-2 bg-white rounded-xl text-xs border border-stone-250 focus:outline-none focus:ring-1 focus:ring-purple-300 shadow-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-stone-500 mb-1">Session Type</label>
                  <select
                    value={newRemType}
                    onChange={e => setNewRemType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white rounded-xl text-xs border border-stone-250 focus:outline-none focus:ring-1 focus:ring-purple-300 shadow-xs"
                  >
                    <option value="gym">🏋 Gym Strength</option>
                    <option value="running">🏃 Running Circuit</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-500 mb-1">Repeat on days</label>
                <div className="flex flex-wrap gap-1.5 font-mono">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => {
                    const selected = newRemDays.includes(day);
                    return (
                      <button
                        type="button"
                        key={day}
                        onClick={() => handleToggleDay(day)}
                        className={`text-[10px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                          selected 
                            ? 'bg-purple-600 font-bold border-purple-500 text-white shadow-xs' 
                            : 'bg-white border-stone-200 text-stone-500 hover:bg-stone-100'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-xl text-xs shadow-md transition-all cursor-pointer"
              >
                Schedule Workout Alert
              </button>
            </form>
          </div>
        </div>
      </div>

      <SpotifyIntegrationPanel workouts={workouts} meals={meals} />

    </div>
  );
}
