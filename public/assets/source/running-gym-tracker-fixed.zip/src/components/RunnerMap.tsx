/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { APIProvider, Map, AdvancedMarker, Pin, useMap } from '@vis.gl/react-google-maps';
import { Compass, Sparkles, AlertCircle, Info } from 'lucide-react';

// Get API Key from process env mapped from secrets
const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';

const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY' && API_KEY.trim().length > 10;

export interface Trail {
  id: string;
  name: string;
  city: string;
  center: { lat: number; lng: number };
  zoom: number;
  path: { lat: number; lng: number }[];
  icon: string;
}

// 4 Beautiful precalculated running routes around iconic global paths
export const PRESET_TRAILS: Trail[] = [
  {
    id: 'central-park',
    name: 'Reservoir Loop',
    city: 'Central Park, NYC',
    center: { lat: 40.7871, lng: -73.9655 },
    zoom: 15,
    icon: '🌳',
    path: [
      { lat: 40.7895, lng: -73.9669 },
      { lat: 40.7891, lng: -73.9642 },
      { lat: 40.7872, lng: -73.9625 },
      { lat: 40.7848, lng: -73.9632 },
      { lat: 40.7839, lng: -73.9658 },
      { lat: 40.7845, lng: -73.9681 },
      { lat: 40.7874, lng: -73.9688 },
      { lat: 40.7892, lng: -73.9682 },
      { lat: 40.7895, lng: -73.9669 }
    ]
  },
  {
    id: 'marina-bay',
    name: 'Waterfront Promenade',
    city: 'Marina Bay, SG',
    center: { lat: 1.2842, lng: 103.8562 },
    zoom: 15,
    icon: '🇸🇬',
    path: [
      { lat: 1.2862, lng: 103.8542 },
      { lat: 1.2858, lng: 103.8586 },
      { lat: 1.2825, lng: 103.8610 },
      { lat: 1.2804, lng: 103.8595 },
      { lat: 1.2801, lng: 103.8550 },
      { lat: 1.2820, lng: 103.8533 },
      { lat: 1.2862, lng: 103.8542 }
    ]
  },
  {
    id: 'golden-gate',
    name: 'Presidio Loop Trail',
    city: 'Golden Gate Park, SF',
    center: { lat: 37.7695, lng: -122.4860 },
    zoom: 14,
    icon: '🌉',
    path: [
      { lat: 37.7712, lng: -122.4910 },
      { lat: 37.7725, lng: -122.4810 },
      { lat: 37.7680, lng: -122.4815 },
      { lat: 37.7668, lng: -122.4905 },
      { lat: 37.7712, lng: -122.4910 }
    ]
  },
  {
    id: 'hyde-park',
    name: 'Serpentine Trail',
    city: 'Hyde Park, London',
    center: { lat: 51.5072, lng: -0.1630 },
    zoom: 15,
    icon: '💂',
    path: [
      { lat: 51.5098, lng: -0.1668 },
      { lat: 51.5085, lng: -0.1575 },
      { lat: 51.5042, lng: -0.1592 },
      { lat: 51.5055, lng: -0.1685 },
      { lat: 51.5098, lng: -0.1668 }
    ]
  }
];

// Helper Polyline drawing component using vis.gl react-google-maps hook
function MapPolyline({ path, color = '#a855f7' }: { path: { lat: number; lng: number }[]; color?: string }) {
  const map = useMap();
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  useEffect(() => {
    if (!map) return;

    if (polylineRef.current) {
      polylineRef.current.setMap(null);
    }

    const poly = new google.maps.Polyline({
      path,
      strokeColor: color,
      strokeOpacity: 0.85,
      strokeWeight: 4,
      geodesic: true,
    });

    poly.setMap(map);
    polylineRef.current = poly;

    return () => {
      poly.setMap(null);
    };
  }, [map, path, color]);

  return null;
}

// Controller component to smoothly auto-pan map to current runner or selected trail
function MapController({ 
  center, 
  zoom, 
  runnerPosition, 
  isSimulating 
}: { 
  center: { lat: number; lng: number }; 
  zoom: number; 
  runnerPosition: { lat: number; lng: number } | null; 
  isSimulating: boolean;
}) {
  const map = useMap();

  useEffect(() => {
    if (!map) return;
    if (isSimulating && runnerPosition) {
      map.panTo(runnerPosition);
    } else {
      map.panTo(center);
      map.setZoom(zoom);
    }
  }, [map, center, zoom, runnerPosition, isSimulating]);

  return null;
}

interface RunnerMapProps {
  selectedTrailIdx: number;
  simPathIdx: number;
  isSimulating: boolean;
  themeColorway?: string;
}

export default function RunnerMap({ 
  selectedTrailIdx, 
  simPathIdx, 
  isSimulating,
  themeColorway = 'blossom' 
}: RunnerMapProps) {
  const trail = PRESET_TRAILS[selectedTrailIdx] || PRESET_TRAILS[0];

  // Intercept exact runner position based on path index (0 - 99 percent along array)
  const currentRunnerPos = useMemo(() => {
    const list = trail.path;
    const total = list.length;
    if (total === 0) return null;

    const floatIdx = (simPathIdx / 100) * (total - 1);
    const lowIdx = Math.floor(floatIdx);
    const highIdx = Math.min(lowIdx + 1, total - 1);
    const t = floatIdx - lowIdx;

    const p1 = list[lowIdx];
    const p2 = list[highIdx];

    return {
      lat: p1.lat + (p2.lat - p1.lat) * t,
      lng: p1.lng + (p2.lng - p1.lng) * t
    };
  }, [trail, simPathIdx]);

  // Handle color choices linked to theme
  const polylineColor = useMemo(() => {
    switch (themeColorway) {
      case 'blossom': return '#f43f5e'; // rose-500
      case 'oceanic': return '#0284c7'; // sky-600
      case 'matcha': return '#10b981'; // emerald-500
      case 'cosmic': return '#8b5cf6'; // violet-500
      default: return '#a855f7';
    }
  }, [themeColorway]);

  // Render inline instruction helper splash box when key is missing under environment constraints
  if (!hasValidKey) {
    return (
      <div className="bg-stone-50/50 border border-stone-200/60 p-6 rounded-2xl text-center min-h-[340px] flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-full flex items-center justify-center shadow-xs">
          <Compass className="w-6 h-6 animate-spin" />
        </div>
        
        <div className="max-w-md">
          <h4 className="text-sm font-semibold text-stone-850">Google Maps Experience Available</h4>
          <p className="text-xs text-stone-400 mt-1.5 leading-relaxed">
            Enter your Google Maps Platform key to replace simple stadium tracks with coordinates mapping!
          </p>
        </div>

        <div className="bg-white border border-stone-200/80 p-4 rounded-xl text-left max-w-sm w-full space-y-2.5 shadow-inner">
          <div className="flex items-start gap-2 text-[10.5px] text-stone-605 leading-snug">
            <span className="font-mono font-bold text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">1.</span>
            <span>Get a valid Maps API Key from the Google Cloud Console.</span>
          </div>
          <div className="flex items-start gap-2 text-[10.5px] text-stone-605 leading-snug">
            <span className="font-mono font-bold text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">2.</span>
            <span>Click <strong>Settings</strong> (⚙️ gear icon, top-right) Select <strong>Secrets</strong>.</span>
          </div>
          <div className="flex items-start gap-2 text-[10.5px] text-stone-605 leading-snug">
            <span className="font-mono font-bold text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">3.</span>
            <span>Type <code>GOOGLE_MAPS_PLATFORM_KEY</code> as the name, paste key as value and click Add.</span>
          </div>
        </div>
        
        <div className="text-[10px] font-mono text-stone-400">
          The applet will automatically recompile and load maps once entered.
        </div>
      </div>
    );
  }

  // Loaded actual maps implementation utilizing react-google-maps SDK
  return (
    <div className="w-full relative rounded-2xl overflow-hidden border border-stone-200/60 shadow-inner h-[280px]">
      <APIProvider apiKey={API_KEY} version="weekly">
        <Map
          defaultCenter={trail.center}
          defaultZoom={trail.zoom}
          mapId="AURA_LIVE_CORE_MAP"
          gestureHandling="cooperative"
          disableDefaultUI={true}
          style={{ width: '100%', height: '100%' }}
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        >
          {/* Automatically compute pan updates to follow the runner or center the trail */}
          <MapController 
            center={trail.center} 
            zoom={trail.zoom} 
            runnerPosition={currentRunnerPos} 
            isSimulating={isSimulating} 
          />

          {/* Preset Trail line drawn beautifully on map */}
          <MapPolyline path={trail.path} color={polylineColor} />

          {/* Starting Flag Marker */}
          {trail.path.length > 0 && (
            <AdvancedMarker position={trail.path[0]} title="Start Point">
              <div className="p-1 px-1.5 bg-zinc-900 text-white rounded text-[8px] font-mono font-medium shadow-xs border border-white">
                START
              </div>
            </AdvancedMarker>
          )}

          {/* Gliding Live Runner Marker on Route */}
          {currentRunnerPos && (
            <AdvancedMarker 
              position={currentRunnerPos} 
              title="My Running Avatar"
              className="transition-transform duration-[100ms] ease-linear"
            >
              <div 
                className="w-8 h-8 rounded-full border-2 border-white shadow-md flex items-center justify-center text-sm transform hover:scale-110 bg-linear-to-tr"
                style={{
                  backgroundImage: themeColorway === 'blossom' ? 'linear-gradient(to top right, #f43f5e, #fda4af)' :
                                   themeColorway === 'oceanic' ? 'linear-gradient(to top right, #0284c7, #7dd3fc)' :
                                   themeColorway === 'matcha' ? 'linear-gradient(to top right, #10b981, #6ee7b7)' :
                                   'linear-gradient(to top right, #8b5cf6, #c084fc)'
                }}
              >
                🏃
              </div>
            </AdvancedMarker>
          )}
        </Map>
      </APIProvider>

      {/* Mini details badge layered atop the map */}
      <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-xs p-2.5 px-3 rounded-xl border border-stone-200 shadow-sm flex items-center gap-2 max-w-[240px]">
        <span className="text-sm">{trail.icon}</span>
        <div>
          <h5 className="text-[11px] font-bold text-stone-800 leading-none">{trail.name}</h5>
          <span className="text-[9px] font-mono text-stone-400 mt-0.5 block">{trail.city}</span>
        </div>
      </div>
    </div>
  );
}
