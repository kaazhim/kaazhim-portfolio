/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Smartphone, Check, Copy, Code, Sparkles, BookOpen, Terminal, CheckCircle2 } from 'lucide-react';

export default function FlutterBridgePanel() {
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeInstructionTab, setActiveInstructionTab] = useState<'dart' | 'setup' | 'permissions'>('dart');

  const flutterCodeSnippet = `import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aura Active Mobile app',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFC084FC),
          brightness: Brightness.light,
        ),
      ),
      home: const AuraActiveContainer(),
    );
  }
}

class AuraActiveContainer extends StatefulWidget {
  const AuraActiveContainer({super.key});

  @override
  State<AuraActiveContainer> createState() => _AuraActiveContainerState();
}

class _AuraActiveContainerState extends State<AuraActiveContainer> {
  late final WebViewController controller;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
          },
          onPageStarted: (String url) {
            setState(() {
              isLoading = true;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              isLoading = false;
            });
          },
        ),
      )
      ..loadRequest(Uri.parse('${window.location.origin}'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAF9),
      body: SafeArea(
        child: Stack(
          children: [
            WebViewWidget(controller: controller),
            if (isLoading)
              const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFFC084FC),
                ),
              ),
          ],
        ),
      ),
    );
  }
}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(flutterCodeSnippet);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-8" id="flutter-bridge-root">
      
      {/* Intro Header */}
      <div className="border-b border-stone-100 pb-5">
        <span className="text-xs uppercase tracking-widest text-purple-600 font-mono font-bold bg-purple-50 px-3 py-1 rounded-full border border-purple-100 inline-block">
          ⚡ Flutter Studio Extension Native Bridge
        </span>
        <h1 className="text-4xl font-light tracking-tight text-stone-800 mt-3">
          Launch Aura Active inside Android Studio
        </h1>
        <p className="text-stone-400 text-sm mt-1">
          Complete cross-platform mobile wrapper build configuration for your wellness dashboard.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Interactive 3D Android Phone Sandbox */}
        <div className="lg:col-span-5 flex flex-col justify-between bg-[#faf5ff]/40 border border-purple-100/80 rounded-3xl p-6 relative overflow-hidden h-[630px] shadow-sm">
          <div className="absolute top-0 right-0 w-32 h-32 bg-purple-200/20 rounded-full blur-3xl pointer-events-none" />
          
          <div>
            <div className="flex justify-between items-center mb-4">
              <span className="text-[11px] font-mono text-purple-600 uppercase tracking-widest font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Android Device Sandbox
              </span>
              <span className="text-[10px] font-mono bg-emerald-50 text-emerald-600 border border-emerald-200 px-2 py-0.5 rounded-full">
                ONLINE SIMULATION
              </span>
            </div>
            
            <p className="text-xs text-stone-500 mb-6">
              Interact below to see how our gorgeous fluid themes adjust inside a native Android view!
            </p>
          </div>

          {/* Interactive 3D Phone body container */}
          <div className="flex-1 flex justify-center items-center">
            <div 
              className="w-[260px] h-[480px] bg-stone-900 rounded-[3rem] border-4 border-stone-800 shadow-2xl relative flex flex-col justify-between overflow-hidden p-3 transition-all duration-500 hover:scale-[1.02] hover:rotate-2 hover:shadow-purple-300/30"
              style={{
                boxShadow: '0 25px 50px -12px rgba(139, 92, 246, 0.15), 0 0 0 1px rgba(139, 92, 246, 0.05)'
              }}
            >
              {/* Inner screen camera notch */}
              <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-16 h-4 bg-stone-900 rounded-full z-20 flex items-center justify-center">
                <div className="w-2.5 h-2.5 bg-zinc-800 rounded-full" />
              </div>

              {/* Glowing Ambient Screen Simulation */}
              <div className="flex-1 rounded-[2.2rem] bg-gradient-to-tr from-pink-50 via-purple-50 to-sky-50 overflow-hidden relative border border-zinc-850 flex flex-col justify-between p-4 pt-8 text-stone-800">
                
                {/* Simulated Header */}
                <div className="flex justify-between items-center text-[10px] text-stone-400 font-mono">
                  <span>Aura Active</span>
                  <div className="flex items-center gap-1">
                    <span>9:41 AM</span>
                    <Smartphone className="w-3 h-3" />
                  </div>
                </div>

                {/* Simulated App Contents */}
                <div className="space-y-3.5 my-auto text-left">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold text-xs">
                      A
                    </div>
                    <div>
                      <span className="font-bold text-xs block text-stone-700 tracking-tight font-display">AURA MOBILE</span>
                      <span className="text-[8px] font-mono text-purple-600 uppercase">Flutter Wrapper Connected</span>
                    </div>
                  </div>

                  {/* Glass Card Simulation */}
                  <div className="bg-white/80 backdrop-blur-md border border-white p-3 rounded-2xl shadow-xs space-y-2">
                    <span className="text-[9px] uppercase font-mono tracking-wider text-rose-500 font-bold block">Hydration Goal</span>
                    <div className="flex justify-between items-baseline">
                      <span className="text-base font-bold text-stone-800">1,250 ml</span>
                      <span className="text-[9px] text-stone-400">Target hit</span>
                    </div>
                    <div className="w-full bg-stone-200/50 h-2 rounded-full overflow-hidden">
                      <div className="w-3/5 bg-sky-400 h-full rounded-full animate-pulse" />
                    </div>
                  </div>

                  {/* Activity Simulator inside phone */}
                  <div className="bg-white/80 backdrop-blur-md border border-white p-3 rounded-2xl shadow-xs">
                    <div className="flex justify-between items-center text-[9px] uppercase font-mono tracking-wider text-emerald-600 font-bold mb-1">
                      <span>Cardio Run status</span>
                      <span className="animate-ping w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    </div>
                    <p className="text-xs font-semibold text-stone-700">Evening Track Practice</p>
                    <p className="text-[9px] text-stone-400 font-mono">Distance completed: 4.8 km</p>
                  </div>
                </div>

                {/* Simulated Screen bottom indicator */}
                <div className="w-16 h-1 bg-stone-400 rounded-full mx-auto" />
              </div>

            </div>
          </div>

        </div>

        {/* Right Column: Code Generator + Steps with Copy trigger */}
        <div className="lg:col-span-7 flex flex-col h-[630px] bg-white border border-stone-100 rounded-3xl p-6 shadow-sm justify-between">
          
          <div>
            {/* Instruction headers */}
            <div className="flex border-b border-stone-100 pb-1 gap-1.5 mb-6">
              <button 
                onClick={() => setActiveInstructionTab('dart')}
                className={`py-2 px-4 rounded-xl text-xs font-semibold tracking-tight transition cursor-pointer flex items-center gap-1.5 ${
                  activeInstructionTab === 'dart' ? 'bg-purple-100 text-purple-700' : 'text-stone-400 hover:text-stone-700'
                }`}
              >
                <Code className="w-3.5 h-3.5" />
                Flutter main.dart
              </button>
              
              <button 
                onClick={() => setActiveInstructionTab('setup')}
                className={`py-2 px-4 rounded-xl text-xs font-semibold tracking-tight transition cursor-pointer flex items-center gap-1.5 ${
                  activeInstructionTab === 'setup' ? 'bg-purple-100 text-purple-700' : 'text-stone-400 hover:text-stone-700'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                Android Studio Steps
              </button>

              <button 
                onClick={() => setActiveInstructionTab('permissions')}
                className={`py-2 px-4 rounded-xl text-xs font-semibold tracking-tight transition cursor-pointer flex items-center gap-1.5 ${
                  activeInstructionTab === 'permissions' ? 'bg-purple-100 text-purple-700' : 'text-stone-400 hover:text-stone-700'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                Manifest Setup
              </button>
            </div>

            {/* Instruction pane renders */}
            {activeInstructionTab === 'dart' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center bg-stone-50 p-2.5 rounded-xl border border-stone-200/50">
                  <div className="text-xs text-stone-600 font-medium">
                    This file wraps your live Aura Active webapp directly into your Flutter android emulator.
                  </div>
                  <button 
                    onClick={handleCopyCode}
                    className="flex items-center gap-1.5 bg-white text-stone-700 border border-stone-300 hover:bg-stone-50 px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedCode ? 'Copied' : 'Copy'}
                  </button>
                </div>

                <div className="bg-[#1e1e1e] rounded-2xl overflow-hidden p-4 relative font-mono text-[11px] leading-relaxed text-stone-300 max-h-[300px] overflow-y-auto border border-zinc-800">
                  <pre className="whitespace-pre overflow-x-auto select-all">{flutterCodeSnippet}</pre>
                </div>
              </div>
            )}

            {activeInstructionTab === 'setup' && (
              <div className="space-y-4 text-xs text-stone-600">
                <div className="p-4 bg-teal-50/[0.2] border border-teal-100 rounded-2xl flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-teal-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-stone-800">1. Initialize a Flutter Project</h5>
                    <p className="text-[11px] text-stone-500 mt-0.5">Open Android Studio, select "Initialize Flutter Project", and confirm your SDK paths.</p>
                  </div>
                </div>

                <div className="p-4 bg-purple-50/[0.2] border border-purple-100 rounded-2xl flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-purple-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-stone-800">2. Include webview_flutter Dependency</h5>
                    <p className="text-[11px] text-stone-500 mt-0.5">Add <code className="font-mono bg-purple-50 px-1 py-0.5 rounded text-purple-600">webview_flutter: ^4.10.0</code> inside your <code className="font-mono">pubspec.yaml</code> and run pub get.</p>
                  </div>
                </div>

                <div className="p-4 bg-sky-50/[0.2] border border-sky-100 rounded-2xl flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-sky-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-stone-800">3. Replace lib/main.dart</h5>
                    <p className="text-[11px] text-stone-500 mt-0.5">Insert our compiled wrapper dart code directly. It hooks dynamically into your live secure developer address!</p>
                  </div>
                </div>
              </div>
            )}

            {activeInstructionTab === 'permissions' && (
              <div className="space-y-4">
                <div className="flex flex-col gap-2 p-4 bg-stone-50 border border-stone-200/50 rounded-2xl">
                  <h5 className="text-xs font-semibold text-stone-700">Add Internet Directives under AndroidManifest.xml:</h5>
                  <p className="text-[11px] text-stone-500">Ensure the following tag is configured above the application tag so the emulator can render real-time charts:</p>
                  <pre className="bg-[#1e1e1e] p-2.5 rounded-lg border border-zinc-800 text-[10px] text-rose-300 font-mono mt-1 select-all whitespace-pre overflow-x-auto">
                    {`<uses-permission android:name="android.permission.INTERNET" />`}
                  </pre>
                </div>

                <div className="flex flex-col gap-2 p-4 bg-stone-50 border border-stone-200/50 rounded-2xl">
                  <h5 className="text-xs font-semibold text-stone-700">Add Transport Security Allowance for local/http connections:</h5>
                  <p className="text-[11px] text-stone-500">Append network security usesCleartextTraffic setting into the AndroidManifest's application header to bypass restrictions:</p>
                  <pre className="bg-[#1e1e1e] p-2.5 rounded-lg border border-zinc-800 text-[10px] text-emerald-300 font-mono mt-1 select-all whitespace-pre overflow-x-auto">
                    {`android:usesCleartextTraffic="true"`}
                  </pre>
                </div>
              </div>
            )}
          </div>

          <div className="mt-8 pt-4 border-t border-stone-100 text-stone-400 text-xs flex justify-between items-center font-mono">
            <span>Minimum SDK limit: API 21+</span>
            <span className="text-purple-600 font-medium">Ready for compilation</span>
          </div>

        </div>

      </div>

    </div>
  );
}
