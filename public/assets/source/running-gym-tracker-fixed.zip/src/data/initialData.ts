/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Workout, Meal, DailyMetrics, UserGoals } from '../types';

// Helper to get formatted dates relative to today
const getPastDate = (daysAgo: number): string => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
};

export const INITIAL_GOALS: UserGoals = {
  dailyWaterMl: 2500,
  dailyCaloriesBurned: 500,
  dailyCalorieIntake: 2200,
  weeklyRunningDistanceKm: 25,
  weeklyGymWorkouts: 4,
};

export const INITIAL_METRICS: DailyMetrics[] = [
  {
    date: getPastDate(6),
    waterIntakeMl: 2200,
    waterGoalMl: 2500,
    weightKg: 78.2,
    sleepHours: 7.5,
    activeMinutes: 45,
  },
  {
    date: getPastDate(5),
    waterIntakeMl: 2600,
    waterGoalMl: 2500,
    weightKg: 78.1,
    sleepHours: 8.0,
    activeMinutes: 65,
  },
  {
    date: getPastDate(4),
    waterIntakeMl: 1800,
    waterGoalMl: 2500,
    weightKg: 78.3,
    sleepHours: 6.8,
    activeMinutes: 30,
  },
  {
    date: getPastDate(3),
    waterIntakeMl: 2500,
    waterGoalMl: 2500,
    weightKg: 78.0,
    sleepHours: 7.2,
    activeMinutes: 75,
  },
  {
    date: getPastDate(2),
    waterIntakeMl: 2400,
    waterGoalMl: 2500,
    weightKg: 77.9,
    sleepHours: 7.4,
    activeMinutes: 50,
  },
  {
    date: getPastDate(1),
    waterIntakeMl: 2800,
    waterGoalMl: 2500,
    weightKg: 77.8,
    sleepHours: 8.2,
    activeMinutes: 90,
  },
  {
    date: getPastDate(0), // Today
    waterIntakeMl: 1500,
    waterGoalMl: 2500,
    weightKg: 77.7,
    sleepHours: 7.0,
    activeMinutes: 40,
  },
];

export const INITIAL_WORKOUTS: Workout[] = [
  // Gym Push Workout - 5 days ago
  {
    id: 'w-1',
    date: getPastDate(5),
    type: 'gym',
    durationMinutes: 60,
    caloriesBurned: 420,
    isCompleted: true,
    notes: 'Focused on high volume chest and shoulders. Felt very strong.',
    gymType: 'push',
    exercises: [
      {
        id: 'ex-1-1',
        name: 'Incline Dumbbell Bench Press',
        category: 'strength',
        targetMuscle: 'Chest',
        sets: [
          { id: 's-1-1-1', reps: 10, weightKg: 28, isCompleted: true },
          { id: 's-1-1-2', reps: 10, weightKg: 28, isCompleted: true },
          { id: 's-1-1-3', reps: 8, weightKg: 30, isCompleted: true },
        ],
      },
      {
        id: 'ex-1-2',
        name: 'Seated Overhead barbell Press',
        category: 'strength',
        targetMuscle: 'Shoulders',
        sets: [
          { id: 's-1-2-1', reps: 12, weightKg: 40, isCompleted: true },
          { id: 's-1-2-2', reps: 10, weightKg: 45, isCompleted: true },
          { id: 's-1-2-3', reps: 8, weightKg: 45, isCompleted: true },
        ],
      },
      {
        id: 'ex-1-3',
        name: 'Tricep Rope Overhead Extension',
        category: 'hypertrophy',
        targetMuscle: 'Triceps',
        sets: [
          { id: 's-1-3-1', reps: 15, weightKg: 18, isCompleted: true },
          { id: 's-1-3-2', reps: 12, weightKg: 22, isCompleted: true },
          { id: 's-1-3-3', reps: 12, weightKg: 22, isCompleted: true },
        ],
      },
    ],
  },
  // Running Workout - 4 days ago
  {
    id: 'w-2',
    date: getPastDate(4),
    type: 'running',
    durationMinutes: 32,
    caloriesBurned: 380,
    isCompleted: true,
    notes: 'A pleasant afternoon intervals road run.',
    distanceKm: 5.2,
    pacePerKm: '06:09',
    routeType: 'road',
    elevationGainM: 45,
    averageHeartRate: 152,
  },
  // Gym Pull Workout - 3 days ago
  {
    id: 'w-3',
    date: getPastDate(3),
    type: 'gym',
    durationMinutes: 65,
    caloriesBurned: 450,
    isCompleted: true,
    notes: 'Back & Biceps day. Cable rows felt fantastic.',
    gymType: 'pull',
    exercises: [
      {
        id: 'ex-3-1',
        name: 'Lat Pulldown (Wide Grip)',
        category: 'strength',
        targetMuscle: 'Back',
        sets: [
          { id: 's-3-1-1', reps: 12, weightKg: 54, isCompleted: true },
          { id: 's-3-1-2', reps: 10, weightKg: 61, isCompleted: true },
          { id: 's-3-1-3', reps: 8, weightKg: 68, isCompleted: true },
        ],
      },
      {
        id: 'ex-3-2',
        name: 'Chest Supported Dumbbell Row',
        category: 'strength',
        targetMuscle: 'Back2',
        sets: [
          { id: 's-3-2-1', reps: 10, weightKg: 22, isCompleted: true },
          { id: 's-3-2-2', reps: 10, weightKg: 22, isCompleted: true },
          { id: 's-3-2-3', reps: 10, weightKg: 24, isCompleted: true },
        ],
      },
      {
        id: 'ex-3-3',
        name: 'Incline Dumbbell Bicep Curl',
        category: 'hypertrophy',
        targetMuscle: 'Biceps',
        sets: [
          { id: 's-3-3-1', reps: 12, weightKg: 10, isCompleted: true },
          { id: 's-3-3-2', reps: 12, weightKg: 10, isCompleted: true },
          { id: 's-3-3-3', reps: 10, weightKg: 12, isCompleted: true },
        ],
      },
    ],
  },
  // Running Workout - 2 days ago
  {
    id: 'w-4',
    date: getPastDate(2),
    type: 'running',
    durationMinutes: 48,
    caloriesBurned: 580,
    isCompleted: true,
    notes: 'Steady aerobic endurance run. Beautiful crisp air.',
    distanceKm: 8.5,
    pacePerKm: '05:38',
    routeType: 'park',
    elevationGainM: 12,
    averageHeartRate: 144,
  } as any,
  // Gym Legs Workout - 1 day ago
  {
    id: 'w-5',
    date: getPastDate(1),
    type: 'gym',
    durationMinutes: 70,
    caloriesBurned: 550,
    isCompleted: true,
    notes: 'Heavy squats. Quads are absolutely toasted.',
    gymType: 'legs',
    exercises: [
      {
        id: 'ex-5-1',
        name: 'Barbell Back Squat',
        category: 'strength',
        targetMuscle: 'Quads',
        sets: [
          { id: 's-5-1-1', reps: 8, weightKg: 80, isCompleted: true },
          { id: 's-5-1-2', reps: 8, weightKg: 90, isCompleted: true },
          { id: 's-5-1-3', reps: 6, weightKg: 100, isCompleted: true },
          { id: 's-5-1-4', reps: 5, weightKg: 105, isCompleted: true },
        ],
      },
      {
        id: 'ex-5-2',
        name: 'Romanian Deadlift (Dumbbell)',
        category: 'strength',
        targetMuscle: 'Hamstrings',
        sets: [
          { id: 's-5-2-1', reps: 10, weightKg: 26, isCompleted: true },
          { id: 's-5-2-2', reps: 10, weightKg: 28, isCompleted: true },
          { id: 's-5-2-3', reps: 10, weightKg: 28, isCompleted: true },
        ],
      },
      {
        id: 'ex-5-3',
        name: 'Standing Calf Raise',
        category: 'hypertrophy',
        targetMuscle: 'Calves',
        sets: [
          { id: 's-5-3-1', reps: 15, weightKg: 40, isCompleted: true },
          { id: 's-5-3-2', reps: 15, weightKg: 40, isCompleted: true },
        ],
      },
    ],
  },
  // Running Workout - Today
  {
    id: 'w-6',
    date: getPastDate(0),
    type: 'running',
    durationMinutes: 24,
    caloriesBurned: 290,
    isCompleted: true,
    notes: 'Short fast running on the track. Warmup and speedwork.',
    distanceKm: 4.1,
    pacePerKm: '05:51',
    routeType: 'track',
    elevationGainM: 5,
    averageHeartRate: 158,
  },
];

export const INITIAL_MEALS: Meal[] = [
  {
    id: 'm-1',
    mealTime: 'breakfast',
    name: 'Strawberry Banana Oatmeal Bowl',
    isCompleted: true,
    notes: 'Added extra honey',
    items: [
      {
        id: 'i-1-1',
        name: 'Rolled Oats',
        calories: 220,
        proteinG: 8,
        carbsG: 41,
        fatG: 4,
        servingSize: '60g',
      },
      {
        id: 'i-1-2',
        name: 'Whey Protein Isolate',
        calories: 120,
        proteinG: 26,
        carbsG: 2,
        fatG: 1,
        servingSize: '1 scoop',
      },
      {
        id: 'i-1-3',
        name: 'Blueberries & Honey',
        calories: 85,
        proteinG: 1,
        carbsG: 22,
        fatG: 0,
        servingSize: '1/2 cup + 1 tsp',
      },
    ],
  },
  {
    id: 'm-2',
    mealTime: 'lunch',
    name: 'Grilled Chicken & Quinoa Avocado Bowl',
    isCompleted: true,
    notes: 'Squeeze of fresh lemon juice',
    items: [
      {
        id: 'i-2-1',
        name: 'Chicken Breast (Grilled)',
        calories: 240,
        proteinG: 48,
        carbsG: 0,
        fatG: 5,
        servingSize: '180g',
      },
      {
        id: 'i-2-2',
        name: 'Quinoa (Cooked)',
        calories: 180,
        proteinG: 6,
        carbsG: 32,
        fatG: 3,
        servingSize: '150g',
      },
      {
        id: 'i-2-3',
        name: 'Hass Avocado',
        calories: 160,
        proteinG: 2,
        carbsG: 8,
        fatG: 15,
        servingSize: '1/2 medium',
      },
      {
        id: 'i-2-4',
        name: 'Spinach & Cucumber Salad',
        calories: 35,
        proteinG: 1,
        carbsG: 5,
        fatG: 1,
        servingSize: '1 bowl',
      },
    ],
  },
  {
    id: 'm-3',
    mealTime: 'dinner',
    name: 'Pan-Seared Salmon & Mashed Sweet Potatoes',
    isCompleted: false,
    notes: 'Planned dinner after late leg session',
    items: [
      {
        id: 'i-3-1',
        name: 'Salmon Fillet',
        calories: 320,
        proteinG: 34,
        carbsG: 0,
        fatG: 18,
        servingSize: '150g',
      },
      {
        id: 'i-3-2',
        name: 'Sweet Potatoes (Steamed)',
        calories: 150,
        proteinG: 3,
        carbsG: 35,
        fatG: 0,
        servingSize: '175g',
      },
      {
        id: 'i-3-3',
        name: 'Asparagus Spears',
        calories: 45,
        proteinG: 2,
        carbsG: 6,
        fatG: 2,
        servingSize: '1 cup',
      },
    ],
  },
  {
    id: 'm-4',
    mealTime: 'snack',
    name: 'Aesthetic Energy Matcha Latte & Rice Cakes',
    isCompleted: true,
    notes: 'Midday booster',
    items: [
      {
        id: 'i-4-1',
        name: 'Almond Milk Matcha Latte',
        calories: 90,
        proteinG: 2,
        carbsG: 10,
        fatG: 3,
        servingSize: '1 glass',
      },
      {
        id: 'i-4-2',
        name: 'Brown Rice Cakes',
        calories: 110,
        proteinG: 2,
        carbsG: 22,
        fatG: 1,
        servingSize: '3 units',
      },
      {
        id: 'i-4-3',
        name: 'Organic Peanut Butter',
        calories: 188,
        proteinG: 7,
        carbsG: 6,
        fatG: 16,
        servingSize: '1 tbsp',
      },
    ],
  },
];
