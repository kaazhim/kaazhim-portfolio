/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Heart,
  Droplet,
  Compass,
  Utensils,
  BarChart2,
  Calendar,
  Layers,
  Sparkles,
  RefreshCw,
  TrendingDown,
  Smartphone,
  Cpu
} from 'lucide-react';

import { Workout, Meal, DailyMetrics, UserGoals } from './types';
import { INITIAL_WORKOUTS, INITIAL_MEALS, INITIAL_METRICS, INITIAL_GOALS } from './data/initialData';

import DashboardOverview from './components/DashboardOverview';
import WorkoutTracker from './components/WorkoutTracker';
import MealPlanner from './components/MealPlanner';
import AnalyticsPanel from './components/AnalyticsPanel';
import FlutterBridgePanel from './components/FlutterBridgePanel';

type ThemeColorway = 'blossom' | 'oceanic' | 'matcha' | 'cosmic';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [themeColorway, setThemeColorway] = useState<ThemeColorway>(() => {
    const saved = localStorage.getItem('flow_theme_colorway');
    return (saved as ThemeColorway) || 'blossom';
  });

  // React state loaded with LocalStorage persistence checks
  const [workouts, setWorkouts] = useState<Workout[]>(() => {
    const saved = localStorage.getItem('flow_workouts');
    return saved ? JSON.parse(saved) : INITIAL_WORKOUTS;
  });

  const [meals, setMeals] = useState<Meal[]>(() => {
    const saved = localStorage.getItem('flow_meals');
    return saved ? JSON.parse(saved) : INITIAL_MEALS;
  });

  const [metrics, setMetrics] = useState<DailyMetrics[]>(() => {
    const saved = localStorage.getItem('flow_metrics');
    return saved ? JSON.parse(saved) : INITIAL_METRICS;
  });

  const [goals, setGoals] = useState<UserGoals>(() => {
    const saved = localStorage.getItem('flow_goals');
    return saved ? JSON.parse(saved) : INITIAL_GOALS;
  });

  // Keep state synchronized with LocalStorage
  useEffect(() => {
    localStorage.setItem('flow_workouts', JSON.stringify(workouts));
  }, [workouts]);

  useEffect(() => {
    localStorage.setItem('flow_meals', JSON.stringify(meals));
  }, [meals]);

  useEffect(() => {
    localStorage.setItem('flow_metrics', JSON.stringify(metrics));
  }, [metrics]);

  useEffect(() => {
    localStorage.setItem('flow_goals', JSON.stringify(goals));
  }, [goals]);

  // Ensure an entry for Today exists in the metrics log daily row
  const getTodayDateString = () => {
    return new Date().toISOString().split('T')[0];
  };

  const getOrCreateTodayMetrics = (currentMetricsList: DailyMetrics[]): DailyMetrics => {
    const todayStr = getTodayDateString();
    const existing = currentMetricsList.find(m => m.date === todayStr);
    if (existing) return { ...existing };

    // Find yesterday's weight to carry over as nice baseline
    const yesterdayStr = new Date();
    yesterdayStr.setDate(yesterdayStr.getDate() - 1);
    const yesterdayDateStr = yesterdayStr.toISOString().split('T')[0];
    const yesterdayEntry = currentMetricsList.find(m => m.date === yesterdayDateStr);
    const carryWeight = yesterdayEntry?.weightKg || 78.0;

    return {
      date: todayStr,
      waterIntakeMl: 0,
      waterGoalMl: goals.dailyWaterMl,
      weightKg: carryWeight,
      sleepHours: 7.5,
      activeMinutes: 0
    };
  };

  // Water tracking logging
  const handleUpdateWater = (amountMl: number) => {
    const todayStr = getTodayDateString();
    setMetrics(prev => {
      // Find today or create it
      const metricsList = [...prev];
      const todayIdx = metricsList.findIndex(m => m.date === todayStr);
      
      if (todayIdx >= 0) {
        metricsList[todayIdx] = {
          ...metricsList[todayIdx],
          waterIntakeMl: Math.max(0, metricsList[todayIdx].waterIntakeMl + amountMl)
        };
      } else {
        const freshToday = getOrCreateTodayMetrics(prev);
        freshToday.waterIntakeMl = Math.max(0, amountMl);
        metricsList.push(freshToday);
      }
      return metricsList;
    });
  };

  // Adjust Target goals
  const handleUpdateGoals = (newGoals: UserGoals) => {
    setGoals(newGoals);
    // Also retroactively update today's water target in metrics if present
    const todayStr = getTodayDateString();
    setMetrics(prev => {
      return prev.map(m => m.date === todayStr ? { ...m, waterGoalMl: newGoals.dailyWaterMl } : m);
    });
  };

  // Log a new exercise (gym or running)
  const handleAddWorkout = (newWorkout: Workout) => {
    setWorkouts(prev => [newWorkout, ...prev]);

    // Automatically increase today's active minutes in telemetry logs
    const todayStr = getTodayDateString();
    setMetrics(prev => {
      const metricsList = [...prev];
      const todayIdx = metricsList.findIndex(m => m.date === todayStr);

      if (todayIdx >= 0) {
        metricsList[todayIdx] = {
          ...metricsList[todayIdx],
          activeMinutes: metricsList[todayIdx].activeMinutes + newWorkout.durationMinutes
        };
      } else {
        const freshToday = getOrCreateTodayMetrics(prev);
        freshToday.activeMinutes = newWorkout.durationMinutes;
        metricsList.push(freshToday);
      }
      return metricsList;
    });
  };

  // Log weight data point
  const handleUpdateWeight = (weightKg: number) => {
    const todayStr = getTodayDateString();
    setMetrics(prev => {
      const metricsList = [...prev];
      const todayIdx = metricsList.findIndex(m => m.date === todayStr);
      if (todayIdx >= 0) {
        metricsList[todayIdx] = {
          ...metricsList[todayIdx],
          weightKg: weightKg
        };
      } else {
        const freshToday = getOrCreateTodayMetrics(prev);
        freshToday.weightKg = weightKg;
        metricsList.push(freshToday);
      }
      return metricsList;
    });
  };

  const handleDeleteWorkout = (id: string) => {
    setWorkouts(prev => {
      const removed = prev.find(w => w.id === id);
      if (removed) {
        // Also deduct active sweat mins from metrics dynamically
        const removedDate = removed.date;
        setMetrics(m => m.map(item => item.date === removedDate ? {
          ...item,
          activeMinutes: Math.max(0, item.activeMinutes - removed.durationMinutes)
        } : item));
      }
      return prev.filter(w => w.id !== id);
    });
  };

  // Log a new meal planner slot
  const handleAddMeal = (newMeal: Meal) => {
    setMeals(prev => [newMeal, ...prev]);
  };

  const handleToggleMealCompleted = (id: string) => {
    setMeals(prev => prev.map(m => m.id === id ? { ...m, isCompleted: !m.isCompleted } : m));
  };

  const handleDeleteMeal = (id: string) => {
    setMeals(prev => prev.filter(m => m.id !== id));
  };

  // Reset state helper
  const handleResetApplicationState = () => {
    if (window.confirm('Are you absolutely sure you want to restore default initial goals and logs?')) {
      localStorage.removeItem('flow_workouts');
      localStorage.removeItem('flow_meals');
      localStorage.removeItem('flow_metrics');
      localStorage.removeItem('flow_goals');
      localStorage.removeItem('flow_theme_colorway');
      setWorkouts(INITIAL_WORKOUTS);
      setMeals(INITIAL_MEALS);
      setMetrics(INITIAL_METRICS);
      setGoals(INITIAL_GOALS);
      setThemeColorway('blossom');
      setActiveTab('dashboard');
    }
  };

  const getThemeAppBg = () => {
    switch (themeColorway) {
      case 'blossom': return 'bg-gradient-to-tr from-rose-50/70 via-stone-50/50 to-pink-100/40';
      case 'oceanic': return 'bg-gradient-to-tr from-blue-50/70 via-stone-50/50 to-sky-100/40';
      case 'matcha': return 'bg-gradient-to-tr from-emerald-50/70 via-stone-50/50 to-green-100/40';
      case 'cosmic': return 'bg-gradient-to-tr from-violet-50/70 via-stone-50/50 to-fuchsia-100/45';
      default: return 'bg-[#fafaf9]';
    }
  };

  return (
    <div className={`min-h-screen relative overflow-hidden text-stone-900 font-sans selection:bg-purple-100 flex flex-col justify-between transition-all duration-1000 ${getThemeAppBg()}`} id="applet-body">
      
      {/* Dynamic Animated Pastel Backdrop Circles */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        {themeColorway === 'blossom' && (
          <>
            <div className="absolute top-[-10%] left-[-10%] w-[55%] h-[55%] rounded-full bg-rose-200/40 blur-[120px] animate-pulse pointer-events-none" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[65%] h-[65%] rounded-full bg-pink-200/40 blur-[140px] animate-pulse [animation-delay:2s] pointer-events-none" />
            <div className="absolute top-[35%] right-[-5%] w-[45%] h-[45%] rounded-full bg-purple-200/30 blur-[130px] animate-pulse [animation-delay:4s] pointer-events-none" />
            <div className="absolute bottom-[20%] left-[-5%] w-[48%] h-[48%] rounded-full bg-orange-100/40 blur-[110px] animate-pulse [animation-delay:6s] pointer-events-none" />
          </>
        )}
        {themeColorway === 'oceanic' && (
          <>
            <div className="absolute top-[-10%] left-[-10%] w-[55%] h-[55%] rounded-full bg-sky-200/45 blur-[120px] animate-pulse pointer-events-none" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[65%] h-[65%] rounded-full bg-blue-200/40 blur-[140px] animate-pulse [animation-delay:2s] pointer-events-none" />
            <div className="absolute top-[35%] right-[-5%] w-[45%] h-[45%] rounded-full bg-teal-100/40 blur-[130px] animate-pulse [animation-delay:4s] pointer-events-none" />
            <div className="absolute bottom-[20%] left-[-5%] w-[48%] h-[48%] rounded-full bg-emerald-100/35 blur-[110px] animate-pulse [animation-delay:6s] pointer-events-none" />
          </>
        )}
        {themeColorway === 'matcha' && (
          <>
            <div className="absolute top-[-10%] left-[-10%] w-[55%] h-[55%] rounded-full bg-emerald-200/40 blur-[120px] animate-pulse pointer-events-none" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[65%] h-[65%] rounded-full bg-green-200/40 blur-[140px] animate-pulse [animation-delay:2s] pointer-events-none" />
            <div className="absolute top-[35%] right-[-5%] w-[45%] h-[45%] rounded-full bg-amber-100/45 blur-[130px] animate-pulse [animation-delay:4s] pointer-events-none" />
            <div className="absolute bottom-[20%] left-[-5%] w-[48%] h-[48%] rounded-full bg-yellow-105 blur-[110px] animate-pulse [animation-delay:6s] pointer-events-none" />
          </>
        )}
        {themeColorway === 'cosmic' && (
          <>
            <div className="absolute top-[-10%] left-[-10%] w-[55%] h-[55%] rounded-full bg-violet-200/50 blur-[120px] animate-pulse pointer-events-none" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[65%] h-[65%] rounded-full bg-fuchsia-200/45 blur-[140px] animate-pulse [animation-delay:2s] pointer-events-none" />
            <div className="absolute top-[35%] right-[-5%] w-[45%] h-[45%] rounded-full bg-pink-200/35 blur-[130px] animate-pulse [animation-delay:4s] pointer-events-none" />
            <div className="absolute bottom-[20%] left-[-5%] w-[48%] h-[48%] rounded-full bg-teal-200/40 blur-[110px] animate-pulse [animation-delay:6s] pointer-events-none" />
          </>
        )}
      </div>

      {/* Top Banner alert and logo structure */}
      <header className="sticky top-0 z-40 bg-white/70 backdrop-blur-md border-b border-stone-200/50 relative">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          
          {/* Logo element: Aura brand representation */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-zinc-900 rounded-2xl flex items-center justify-center text-white font-display font-bold text-sm shadow-md rotate-3 hover:rotate-12 transition-transform cursor-pointer" id="main-logo-icon">
              A
            </div>
            <div className="hidden sm:block">
              <span className="text-sm font-semibold tracking-tight text-stone-800 font-display block">AURA ACTIVE</span>
              <span className="text-[10px] font-mono text-stone-400 block -mt-1 uppercase tracking-widest">Balanced Flow</span>
            </div>

            {/* Pastel colorway selection pills */}
            <div className="flex items-center gap-1 bg-stone-100/80 p-1 rounded-xl border border-stone-200/60 ml-1.5">
              {(['blossom', 'oceanic', 'matcha', 'cosmic'] as const).map(colorway => (
                <button
                  key={colorway}
                  onClick={() => {
                    setThemeColorway(colorway);
                    localStorage.setItem('flow_theme_colorway', colorway);
                  }}
                  className={`w-4.5 h-4.5 rounded-full transition-all border ${
                    themeColorway === colorway ? 'scale-115 ring-2 ring-purple-400 border-white' : 'border-stone-200 opacity-60 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: 
                      colorway === 'blossom' ? '#fecdd3' :
                      colorway === 'oceanic' ? '#bae6fd' :
                      colorway === 'matcha' ? '#a7f3d0' : '#e9d5ff'
                  }}
                  title={`Trigger ${colorway} pastel environment`}
                />
              ))}
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-stone-100/60 p-1 rounded-full border border-stone-200/45">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all cursor-pointer ${
                activeTab === 'dashboard' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('workouts')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all cursor-pointer ${
                activeTab === 'workouts' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-400 hover:text-stone-700'
              }`}
              id="nav-workouts-tab"
            >
              Logging Trails
            </button>
            <button
              onClick={() => setActiveTab('meals')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all cursor-pointer ${
                activeTab === 'meals' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              Meal Planner
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all cursor-pointer ${
                activeTab === 'analytics' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              Analytics
            </button>
            <button
              onClick={() => setActiveTab('flutter-bridge')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all cursor-pointer flex items-center gap-1 ${
                activeTab === 'flutter-bridge' ? 'bg-white text-purple-700 shadow-sm' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              <Smartphone className="w-3 h-3 text-purple-500" />
              Android Wrapper
            </button>
          </nav>

          {/* Developer Restore and Reset defaults button */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleResetApplicationState}
              className="p-2 bg-stone-50 hover:bg-stone-100 border border-stone-200/80 text-stone-400 hover:text-stone-700 rounded-xl transition-all cursor-pointer"
              title="Reset Application Cache Data"
              id="reset-app-state-btn"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      </header>

      {/* Main interactive tabs viewport */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 relative z-10" id="main-content-viewport">
        
        {/* Render Tab Views according to state selection */}
        {activeTab === 'dashboard' && (
          <DashboardOverview 
            metrics={metrics}
            workouts={workouts}
            meals={meals}
            goals={goals}
            onUpdateWater={handleUpdateWater}
            onUpdateGoals={handleUpdateGoals}
            onAddWorkout={handleAddWorkout}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            themeColorway={themeColorway}
          />
        )}

        {activeTab === 'workouts' && (
          <WorkoutTracker 
            workouts={workouts}
            onAddWorkout={handleAddWorkout}
            onDeleteWorkout={handleDeleteWorkout}
          />
        )}

        {activeTab === 'meals' && (
          <MealPlanner 
            meals={meals}
            dailyCalorieGoal={goals.dailyCalorieIntake}
            onAddMeal={handleAddMeal}
            onToggleMealCompleted={handleToggleMealCompleted}
            onDeleteMeal={handleDeleteMeal}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsPanel 
            workouts={workouts}
            metrics={metrics}
            meals={meals}
            goals={goals}
            onUpdateWeight={handleUpdateWeight}
          />
        )}

        {activeTab === 'flutter-bridge' && (
          <FlutterBridgePanel />
        )}

      </main>

      {/* Mobile Sticky Floating tab bar (Bespoke UX design) */}
      <div className="md:hidden sticky bottom-4 z-40 mx-4 bg-white/90 backdrop-blur-md border border-stone-200/80 p-1.5 rounded-2xl shadow-lg shadow-purple-200/40 flex justify-around">
        
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex-1 py-1 flex flex-col items-center gap-0.5 cursor-pointer ${
            activeTab === 'dashboard' ? 'text-purple-600 font-semibold' : 'text-stone-400'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span className="text-[8px] font-mono">Overview</span>
        </button>

        <button 
          onClick={() => setActiveTab('workouts')}
          className={`flex-1 py-1 flex flex-col items-center gap-0.5 cursor-pointer ${
            activeTab === 'workouts' ? 'text-purple-600 font-semibold' : 'text-stone-400'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span className="text-[8px] font-mono">Workouts</span>
        </button>

        <button 
          onClick={() => setActiveTab('meals')}
          className={`flex-1 py-1 flex flex-col items-center gap-0.5 cursor-pointer ${
            activeTab === 'meals' ? 'text-purple-600 font-semibold' : 'text-stone-400'
          }`}
        >
          <Utensils className="w-4 h-4" />
          <span className="text-[8px] font-mono">Meals</span>
        </button>

        <button 
          onClick={() => setActiveTab('analytics')}
          className={`flex-1 py-1 flex flex-col items-center gap-0.5 cursor-pointer ${
            activeTab === 'analytics' ? 'text-purple-600' : 'text-stone-400'
          }`}
        >
          <BarChart2 className="w-4 h-4" />
          <span className="text-[8px] font-mono">Charts</span>
        </button>

        <button 
          onClick={() => setActiveTab('flutter-bridge')}
          className={`flex-1 py-1 flex flex-col items-center gap-0.5 cursor-pointer ${
            activeTab === 'flutter-bridge' ? 'text-purple-600 font-semibold' : 'text-stone-400'
          }`}
        >
          <Smartphone className="w-4 h-4 text-purple-500" />
          <span className="text-[8px] font-mono">Flutter</span>
        </button>

      </div>

      {/* Footer credits and information */}
      <footer className="bg-white/40 border-t border-stone-200/50 py-6 text-center text-xs text-stone-400 mt-12 pb-16 md:pb-6 relative z-10">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1">
            <Heart className="w-3.5 h-3.5 text-rose-300 fill-rose-300" />
            <span>Aura Active minimalist lifestyle organizer. Balanced & Mindful.</span>
          </div>
          <span>UTC logs active status checker. Updated for consistent gains. © 2026.</span>
        </div>
      </footer>

    </div>
  );
}
